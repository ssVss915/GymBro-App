package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Color Palette
val CyberOrange = Color(0xFFD0BCFF)               // #D0BCFF (Primary Lavender/Purple)
val CyberOrangeVariant = Color(0xFF381E72)        // #381E72 (Muted Deep Purple)
val DeepHydrationBlue = Color(0xFF3B82F6)         // Muted Hydration Blue
val SoftHydrationBlue = Color(0xFF93C5FD)
val NeonDoneGreen = Color(0xFF22C55E)             // Standard Completed Green
val RestPurple = Color(0xFFD0BCFF)                // Resting Purple matching theme

val ObsidianBlack = Color(0xFF111318)             // #111318 (Primary Background)
val DarkGreySurface = Color(0xFF1C1B1F)           // #1C1B1F (Dark Card Surface background)
val DarkGreyBorder = Color(0xFF49454F)            // #49454F (Card outlines and borders)
val TextSecondaryGray = Color(0xFFC4C6CF)         // #C4C6CF (Subtitles and secondary text)

package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ExerciseVideoPlayer(exerciseName: String, modifier: Modifier = Modifier) {
    val nameLower = exerciseName.lowercase()

    val targetMuscle = remember(exerciseName) {
        when {
            nameLower.contains("walk") || nameLower.contains("cardio") -> "Legs & Cardio"
            nameLower.contains("pushup") && !nameLower.contains("pike") -> "Chest & Triceps"
            nameLower.contains("floor press") || nameLower.contains("floor-press") -> "Pectorals (Chest)"
            nameLower.contains("overhead") || nameLower.contains("shoulder press") -> "Deltoids (Shoulders)"
            nameLower.contains("pike") -> "Shoulders & Triceps"
            nameLower.contains("tricep") -> "Triceps Brachii"
            nameLower.contains("row") -> "Latissimus Dorsi (Lats)"
            nameLower.contains("pull") || nameLower.contains("chin") -> "Upper Back & Lats"
            nameLower.contains("leg raise") || nameLower.contains("hang") -> "Abdominals & Core"
            nameLower.contains("squat") -> "Quadriceps & Glutes"
            nameLower.contains("lunge") -> "Quadriceps & Hamstrings"
            nameLower.contains("calf") -> "Calf Muscles"
            nameLower.contains("crunch") || nameLower.contains("ab") -> "Abs / Rectus Abdominis"
            nameLower.contains("plank") -> "Core (Abs & Obliques)"
            nameLower.contains("skipping") || nameLower.contains("jump") || nameLower.contains("rope") || nameLower.contains("rassi") -> "Calves & Cardio"
            nameLower.contains("curl") || nameLower.contains("bicep") || nameLower.contains("hammer") -> "Biceps Brachii"
            nameLower.contains("stretch") -> "Hamstrings & Back"
            else -> "Full Body / Cardio"
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "exerciseAnimation")
    
    // Smooth, biologically accurate 2.6-second rep cycle
    val animationProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "animationProgress"
    )

    // Continuous progress looping forward
    val continuousProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "continuousProgress"
    )

    // microTremble for planks
    val quickTremble by infiniteTransition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(60, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "quickTremble"
    )

    val pulseVal = sin(continuousProgress * 2 * PI * 2.5).toFloat()
    val pulseAlpha = 0.35f + 0.45f * (pulseVal + 1f) / 2f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(Color(0xFF0F0F0F), shape = RoundedCornerShape(24.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerX = canvasWidth / 2f
                val centerY = canvasHeight / 2f

                // Color Scheme configuration for dynamic feedback
                val primaryColor = Color(0xFFF97316)  // Neon Amber Theme orange
                val accentColor = Color(0xFF38BDF8)   // High energy Sky Blue
                val limbColor = Color(0xFFE2E2E6)     // Bone white
                val jointColor = Color(0xFFA1A1AA)    // Slate joint accents
                val groundLineColor = Color(0xFF262626)
                val lineGlowColor = Color(0x22F97316)
                val weightColor = Color(0xFFEF4444)    // Power red weights
                val pulseRadius = 11.dp.toPx() + 7.dp.toPx() * (pulseVal + 1f) / 2f

                // Background high-tech visual design grid (glowing radar circle + ground line)
                drawCircle(color = Color(0xFF1E1E1E), radius = 80.dp.toPx(), center = Offset(centerX, centerY), style = Stroke(width = 1.dp.toPx()))
                drawLine(color = groundLineColor, start = Offset(0f, centerY + 50.dp.toPx()), end = Offset(canvasWidth, centerY + 50.dp.toPx()), strokeWidth = 3.dp.toPx())

                // Route through detailed, high-accuracy human stick skeletal movements
                when {
                    // ---- 1. CYCLIC WALKING / CARDIO STRIDE ----
                    nameLower.contains("walk") || nameLower.contains("cardio") -> {
                        val angle = continuousProgress * 2 * PI
                        
                        val speedPx = continuousProgress * canvasWidth
                        val lineSpacing = canvasWidth / 3f
                        for (i in -1..3) {
                            val lineX = (i * lineSpacing - speedPx + canvasWidth) % canvasWidth
                            drawLine(
                                color = Color(0xFF404040),
                                start = Offset(lineX, centerY + 50.dp.toPx()),
                                end = Offset(lineX + 30.dp.toPx(), centerY + 50.dp.toPx()),
                                strokeWidth = 2.dp.toPx()
                            )
                        }

                        val hipBob = sin(angle * 2).toFloat() * 3.dp.toPx()
                        val hipY = centerY + 10.dp.toPx() + hipBob
                        val shoulderY = centerY - 25.dp.toPx() + hipBob
                        val headY = centerY - 45.dp.toPx() + hipBob

                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        listOf(angle, angle + PI).forEachIndexed { index, phase ->
                            val isLeft = index == 1
                            val limbCol = if (isLeft) Color(0xFFA1A1AA) else Color.White
                            
                            val footSweepX = cos(phase).toFloat() * 25.dp.toPx()
                            val footSweepY = sin(phase).toFloat()
                            val footX = centerX + footSweepX
                            val footY = centerY + 50.dp.toPx() - (if (footSweepY < 0) footSweepY * 18.dp.toPx() else 0f)

                            val kneeX = (centerX + footX) / 2f + (if (footSweepY < 0) 12.dp.toPx() else 4.dp.toPx())
                            val kneeY = (hipY + footY) / 2f - 4.dp.toPx()

                            drawLine(color = limbCol, start = Offset(centerX, hipY), end = Offset(kneeX, kneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = limbCol, start = Offset(kneeX, kneeY), end = Offset(footX, footY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = limbCol, start = Offset(footX, footY), end = Offset(footX + 8.dp.toPx(), footY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(kneeX, kneeY))

                            val calfX = (kneeX + footX) / 2f
                            val calfY = (kneeY + footY) / 2f
                            drawCircle(
                                color = Color(0xFFFF3333).copy(alpha = pulseAlpha * (if (isLeft) 0.35f else 0.65f)),
                                radius = pulseRadius * 0.8f,
                                center = Offset(calfX, calfY)
                            )
                        }

                        listOf(angle + PI, angle).forEachIndexed { index, phase ->
                            val isLeft = index == 1
                            val tCol = if (isLeft) Color(0xFFA1A1AA) else accentColor

                            val armSwingX = cos(phase).toFloat() * 22.dp.toPx()
                            val armSwingY = sin(phase).toFloat() * 8.dp.toPx()

                            val handX = centerX + armSwingX
                            val handY = centerY - 5.dp.toPx() + armSwingY

                            val elbowX = (centerX + handX) / 2f - 4.dp.toPx()
                            val elbowY = (shoulderY + handY) / 2f + 5.dp.toPx()

                            drawLine(color = tCol, start = Offset(centerX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = tCol, start = Offset(elbowX, elbowY), end = Offset(handX, handY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 2.5.dp.toPx(), center = Offset(elbowX, elbowY))
                        }
                    }

                    // ---- 2. PUSHUPS & DIAMOND PUSHUPS ----
                    nameLower.contains("pushup") && !nameLower.contains("pike") -> {
                        val isDiamond = nameLower.contains("diamond")
                        
                        val dipFactor = animationProgress
                        val bodyHeightOffset = dipFactor * 32.dp.toPx()
                        
                        val toesX = centerX - 80.dp.toPx()
                        val toesY = centerY + 42.dp.toPx()
                        
                        val handX = centerX + 25.dp.toPx()
                        val handY = centerY + 48.dp.toPx()

                        val hipY = (centerY + 25.dp.toPx()) + bodyHeightOffset * 0.7f
                        val hipX = centerX - 40.dp.toPx()
                        
                        val shoulderY = (centerY - 5.dp.toPx()) + bodyHeightOffset
                        val shoulderX = centerX + 30.dp.toPx()
                        
                        val headY = (centerY - 18.dp.toPx()) + bodyHeightOffset
                        val headX = centerX + 55.dp.toPx()

                        drawLine(color = limbColor, start = Offset(toesX, toesY), end = Offset(shoulderX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(headX, headY))

                        if (isDiamond) {
                            val diamondHandX = centerX + 5.dp.toPx()
                            val elbowX = centerX - 15.dp.toPx()
                            val elbowY = (shoulderY + handY) / 2f + 16.dp.toPx() - (1f - dipFactor) * 12.dp.toPx()
                            
                            drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(diamondHandX, handY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 4.dp.toPx(), center = Offset(elbowX, elbowY))
                            drawCircle(color = primaryColor, radius = 5.dp.toPx(), center = Offset(diamondHandX, handY))
                        } else {
                            val elbowX = centerX + 12.dp.toPx()
                            val elbowY = centerY + 18.dp.toPx() + (dipFactor * 12.dp.toPx())
                            
                            drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, handY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 4.dp.toPx(), center = Offset(elbowX, elbowY))
                            drawCircle(color = Color.White, radius = 4.dp.toPx(), center = Offset(handX, handY))
                        }

                        val chestX = (shoulderX * 0.75f + hipX * 0.25f)
                        val chestY = (shoulderY * 0.75f + hipY * 0.25f)
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.3f,
                            center = Offset(chestX, chestY)
                        )
                    }

                    // ---- 3. FLOOR PRESS ----
                    nameLower.contains("floor press") || nameLower.contains("floor-press") -> {
                        val pressFactor = 1f - animationProgress
                        val handY = centerY - 25.dp.toPx() + pressFactor * 55.dp.toPx()

                        val backY = centerY + 42.dp.toPx()
                        val headX = centerX - 55.dp.toPx()
                        val hipsX = centerX + 20.dp.toPx()
                        val shoulderX = centerX - 15.dp.toPx()

                        drawLine(color = limbColor, start = Offset(headX - 10.dp.toPx(), backY), end = Offset(hipsX, backY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(headX, backY - 11.dp.toPx()))

                        val kneeX = centerX + 40.dp.toPx()
                        val kneeY = centerY + 15.dp.toPx()
                        val footX = centerX + 55.dp.toPx()
                        drawLine(color = limbColor, start = Offset(hipsX, backY), end = Offset(kneeX, kneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(kneeX, kneeY), end = Offset(footX, backY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val elbowX = shoulderX - 12.dp.toPx() * (pressFactor)
                        val elbowY = backY - (1f - pressFactor) * 12.dp.toPx()

                        drawLine(color = accentColor, start = Offset(shoulderX, backY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(shoulderX, handY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.5.dp.toPx(), center = Offset(elbowX, elbowY))

                        drawLine(color = weightColor, start = Offset(shoulderX - 18.dp.toPx(), handY), end = Offset(shoulderX + 18.dp.toPx(), handY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = Color.White, radius = 9.dp.toPx(), center = Offset(shoulderX - 18.dp.toPx(), handY))
                        drawCircle(color = Color.White, radius = 9.dp.toPx(), center = Offset(shoulderX + 18.dp.toPx(), handY))

                        val chestX = shoulderX
                        val chestY = backY - 8.dp.toPx()
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.3f,
                            center = Offset(chestX, chestY)
                        )
                    }

                    // ---- 4. OVERHEAD / SHOULDER PRESS ----
                    nameLower.contains("overhead") || nameLower.contains("shoulder press") -> {
                        val pressFactor = animationProgress
                        val barHeight = centerY - 32.dp.toPx() - (pressFactor * 60.dp.toPx())

                        val feetY = centerY + 50.dp.toPx()
                        val hipsY = centerY + 12.dp.toPx()
                        val shoulderY = centerY - 24.dp.toPx()

                        drawLine(color = limbColor, start = Offset(centerX, feetY), end = Offset(centerX, hipsY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(centerX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, centerY - 43.dp.toPx()))

                        listOf(-28.dp.toPx(), 28.dp.toPx()).forEach { sideX ->
                            val shoulderX = centerX + (sideX * 0.4f)
                            val handX = centerX + sideX
                            val elbowX = centerX + sideX * 0.9f * (1f - pressFactor * 0.6f)
                            val elbowY = (shoulderY + barHeight) / 2f + 16.dp.toPx() * (1f - pressFactor)

                            drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, barHeight), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))
                        }

                        drawLine(color = Color.DarkGray, start = Offset(centerX - 65.dp.toPx(), barHeight), end = Offset(centerX + 65.dp.toPx(), barHeight), strokeWidth = 3.dp.toPx())
                        listOf(centerX - 65.dp.toPx(), centerX + 65.dp.toPx()).forEach { px ->
                            drawRect(
                                color = weightColor,
                                topLeft = Offset(px - 5.dp.toPx(), barHeight - 16.dp.toPx()),
                                size = androidx.compose.ui.geometry.Size(10.dp.toPx(), 32.dp.toPx())
                            )
                        }

                        listOf(centerX - 10.dp.toPx(), centerX + 10.dp.toPx()).forEach { shX ->
                            drawCircle(
                                color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.6f),
                                radius = pulseRadius * 0.85f,
                                center = Offset(shX, shoulderY)
                            )
                        }
                    }

                    // ---- 5. PIKE PUSHUPS ----
                    nameLower.contains("pike") -> {
                        val pressFactor = animationProgress
                        val dipDistance = pressFactor * 26.dp.toPx()

                        val toesX = centerX - 65.dp.toPx()
                        val toesY = centerY + 45.dp.toPx()
                        
                        val handX = centerX + 40.dp.toPx()
                        val handY = centerY + 48.dp.toPx()

                        val hipsX = centerX - 18.dp.toPx()
                        val hipsY = centerY - 25.dp.toPx()

                        val shoulderX = centerX + 12.dp.toPx() + dipDistance * 0.5f
                        val shoulderY = centerY + 5.dp.toPx() + dipDistance
                        
                        val headX = shoulderX + 18.dp.toPx()
                        val headY = shoulderY + 12.dp.toPx()

                        drawLine(color = limbColor, start = Offset(toesX, toesY), end = Offset(hipsX, hipsY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(hipsX, hipsY), end = Offset(shoulderX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 10.dp.toPx(), center = Offset(headX, headY))

                        val elbowX = centerX + 36.dp.toPx() - (1f - pressFactor) * 12.dp.toPx()
                        val elbowY = (shoulderY + handY) / 2f + 10.dp.toPx()

                        drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, handY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))

                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.1f,
                            center = Offset(shoulderX, shoulderY)
                        )
                    }

                    // ---- 6. TRICEP OVERHEAD EXTENSIONS ----
                    nameLower.contains("tricep") -> {
                        val extFactor = animationProgress
                        val weightY = centerY - 45.dp.toPx() - extFactor * 45.dp.toPx()

                        val feetY = centerY + 50.dp.toPx()
                        val hipsY = centerY + 15.dp.toPx()
                        val shoulderY = centerY - 20.dp.toPx()

                        drawLine(color = limbColor, start = Offset(centerX, feetY), end = Offset(centerX, hipsY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(centerX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, centerY - 38.dp.toPx()))

                        val elbowX = centerX - 12.dp.toPx()
                        val elbowY = centerY - 52.dp.toPx()
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val handX = centerX - 12.dp.toPx() + (extFactor * 10.dp.toPx())
                        drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, weightY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))

                        drawLine(color = weightColor, start = Offset(handX - 16.dp.toPx(), weightY), end = Offset(handX + 16.dp.toPx(), weightY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = Color.White, radius = 8.dp.toPx(), center = Offset(handX - 16.dp.toPx(), weightY))
                        drawCircle(color = Color.White, radius = 8.dp.toPx(), center = Offset(handX + 16.dp.toPx(), weightY))

                        val tricepX = (centerX + elbowX) / 2f
                        val tricepY = (shoulderY + elbowY) / 2f
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 0.9f,
                            center = Offset(tricepX, tricepY)
                        )
                    }

                    // ---- 7. DUMBBELL ROWS / BACK TRAIN ----
                    nameLower.contains("row") -> {
                        val rowFactor = animationProgress
                        
                        val hipsX = centerX - 35.dp.toPx()
                        val hipsY = centerY + 12.dp.toPx()
                        val shoulderX = centerX + 25.dp.toPx()
                        val shoulderY = centerY - 15.dp.toPx()
                        val headX = centerX + 45.dp.toPx()
                        val headY = centerY - 22.dp.toPx()

                        val kneeX = centerX - 25.dp.toPx()
                        val kneeY = centerY + 28.dp.toPx()
                        val footX = centerX - 20.dp.toPx()
                        val footY = centerY + 48.dp.toPx()
                        drawLine(color = limbColor, start = Offset(hipsX, hipsY), end = Offset(kneeX, kneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(kneeX, kneeY), end = Offset(footX, footY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        drawLine(color = limbColor, start = Offset(hipsX, hipsY), end = Offset(shoulderX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 10.dp.toPx(), center = Offset(headX, headY))

                        val handX = centerX + 18.dp.toPx() - (rowFactor * 10.dp.toPx())
                        val handY = centerY + 25.dp.toPx() - (rowFactor * 32.dp.toPx())

                        val elbowX = centerX - (rowFactor * 22.dp.toPx())
                        val elbowY = centerY - 2.dp.toPx() - (rowFactor * 26.dp.toPx())

                        drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, handY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))

                        drawLine(color = weightColor, start = Offset(handX - 16.dp.toPx(), handY), end = Offset(handX + 16.dp.toPx(), handY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = Color.White, radius = 8.dp.toPx(), center = Offset(handX - 16.dp.toPx(), handY))
                        drawCircle(color = Color.White, radius = 8.dp.toPx(), center = Offset(handX + 16.dp.toPx(), handY))

                        val LatX = (hipsX * 0.45f + shoulderX * 0.55f)
                        val LatY = (hipsY * 0.45f + shoulderY * 0.55f)
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.35f,
                            center = Offset(LatX, LatY)
                        )
                    }

                    // ---- 8. PULL-UPS & CHIN-UPS ----
                    nameLower.contains("pull") || nameLower.contains("chin") -> {
                        val isChinUp = nameLower.contains("chin")
                        val barY = centerY - 55.dp.toPx()
                        val pullFactor = animationProgress
                        
                        val rigHeightShift = pullFactor * 42.dp.toPx()
                        val headY = barY + 45.dp.toPx() - rigHeightShift
                        val hipsY = headY + 54.dp.toPx()
                        val shoulderY = headY + 12.dp.toPx()

                        drawLine(color = Color(0xFF404040), start = Offset(centerX - 85.dp.toPx(), barY), end = Offset(centerX + 85.dp.toPx(), barY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)

                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(centerX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        val kneeX = centerX - 6.dp.toPx()
                        val kneeY = hipsY + 28.dp.toPx()
                        val footX = centerX - 2.dp.toPx() + pullFactor * 8.dp.toPx()
                        val footY = kneeY + 25.dp.toPx()
                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(kneeX, kneeY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(kneeX, kneeY), end = Offset(footX, footY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)

                        if (isChinUp) {
                            val gripWidth = 10.dp.toPx()
                            listOf(-gripWidth, gripWidth).forEach { handSide ->
                                val handX = centerX + handSide
                                val elbowX = centerX + handSide * 1.5f * (1f - pullFactor)
                                val elbowY = (shoulderY + barY) / 2f + 18.dp.toPx() * (1f - pullFactor)

                                drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                                drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, barY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                                drawCircle(color = jointColor, radius = 2.5.dp.toPx(), center = Offset(elbowX, elbowY))
                            }
                        } else {
                            val gripWidth = 38.dp.toPx()
                            listOf(-gripWidth, gripWidth).forEach { handSide ->
                                val handX = centerX + handSide
                                val elbowX = centerX + handSide * 1.3f * (1f - pullFactor * 0.7f)
                                val elbowY = (shoulderY + barY) / 2f + 12.dp.toPx() * (1f - pullFactor)

                                drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                                drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, barY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                                drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))
                            }
                        }

                        listOf(-13.dp.toPx(), 13.dp.toPx()).forEach { sideOffset ->
                            val latX = centerX + sideOffset
                            val latY = (shoulderY + hipsY) / 2f
                            drawCircle(
                                color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.65f),
                                radius = pulseRadius * 1.1f,
                                center = Offset(latX, latY)
                            )
                        }
                    }

                    // ---- 9. HANGING LEG RAISES ----
                    nameLower.contains("leg raise") || nameLower.contains("hang") -> {
                        val barY = centerY - 55.dp.toPx()
                        val raiseFactor = animationProgress
                        
                        val headY = barY + 45.dp.toPx()
                        val shoulderY = headY + 12.dp.toPx()
                        val hipsY = headY + 54.dp.toPx()

                        drawLine(color = Color(0xFF404040), start = Offset(centerX - 80.dp.toPx(), barY), end = Offset(centerX + 80.dp.toPx(), barY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(centerX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(centerX - 18.dp.toPx(), barY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(centerX + 18.dp.toPx(), barY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)

                        val legAngleRad = (raiseFactor * 90f) * (PI / 180f)
                        val legLength = 48.dp.toPx()
                        
                        val feetX = centerX + sin(legAngleRad).toFloat() * legLength
                        val feetY = hipsY + cos(legAngleRad).toFloat() * legLength

                        drawLine(color = primaryColor, start = Offset(centerX, hipsY), end = Offset(feetX, feetY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 4.dp.toPx(), center = Offset(centerX, hipsY))

                        val coreY = hipsY - 14.dp.toPx()
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.25f,
                            center = Offset(centerX, coreY)
                        )
                    }

                    // ---- 10. GOBLET SQUATS ----
                    nameLower.contains("squat") -> {
                        val squatFactor = animationProgress
                        
                        val hipY = centerY + 5.dp.toPx() + (squatFactor * 32.dp.toPx())
                        val shoulderY = centerY - 25.dp.toPx() + (squatFactor * 26.dp.toPx())
                        val headY = centerY - 45.dp.toPx() + (squatFactor * 25.dp.toPx())

                        val leftFootX = centerX - 22.dp.toPx()
                        val rightFootX = centerX + 22.dp.toPx()
                        val feetY = centerY + 50.dp.toPx()

                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        listOf(leftFootX, rightFootX).forEach { footX ->
                            val sideMultiplier = if (footX < centerX) -1f else 1f
                            val kneeX = centerX + (sideMultiplier * 36.dp.toPx() * (0.6f + squatFactor * 0.4f))
                            val kneeY = centerY + 28.dp.toPx() + (squatFactor * 10.dp.toPx())

                            drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(kneeX, kneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = limbColor, start = Offset(kneeX, kneeY), end = Offset(footX, feetY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 3.5.dp.toPx(), center = Offset(kneeX, kneeY))

                            val thighX = (centerX + kneeX) / 2f
                            val thighY = (hipY + kneeY) / 2f
                            drawCircle(
                                color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.65f),
                                radius = pulseRadius * 1.15f,
                                center = Offset(thighX, thighY)
                            )
                        }

                        val wtY = shoulderY + 12.dp.toPx()
                        drawLine(color = weightColor, start = Offset(centerX - 10.dp.toPx(), wtY), end = Offset(centerX + 10.dp.toPx(), wtY), strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = Color.White, start = Offset(centerX - 15.dp.toPx(), wtY - 8.dp.toPx()), end = Offset(centerX - 15.dp.toPx(), wtY + 8.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = Color.White, start = Offset(centerX + 15.dp.toPx(), wtY - 8.dp.toPx()), end = Offset(centerX + 15.dp.toPx(), wtY + 8.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                    }

                    // ---- 11. LUNGES ----
                    nameLower.contains("lunge") -> {
                        val lungeFactor = animationProgress
                        
                        val frontFootX = centerX + 35.dp.toPx()
                        val backFootX = centerX - 45.dp.toPx()
                        val groundY = centerY + 48.dp.toPx()

                        val hipX = centerX - 10.dp.toPx()
                        val hipY = centerY + 10.dp.toPx() + (lungeFactor * 26.dp.toPx())
                        val shoulderY = hipY - 35.dp.toPx()

                        drawLine(color = limbColor, start = Offset(hipX, hipY), end = Offset(hipX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 10.5.dp.toPx(), center = Offset(hipX, shoulderY - 14.dp.toPx()))

                        val frontKneeX = frontFootX - 10.dp.toPx() * (1f - lungeFactor)
                        val frontKneeY = hipY + 10.dp.toPx() + (lungeFactor * 12.dp.toPx())
                        drawLine(color = limbColor, start = Offset(hipX, hipY), end = Offset(frontKneeX, frontKneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(frontKneeX, frontKneeY), end = Offset(frontFootX, groundY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(frontKneeX, frontKneeY))

                        val backKneeX = hipX - 12.dp.toPx()
                        val backKneeY = hipY + 20.dp.toPx() + (lungeFactor * 15.dp.toPx())
                        drawLine(color = limbColor, start = Offset(hipX, hipY), end = Offset(backKneeX, backKneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(backKneeX, backKneeY), end = Offset(backFootX, groundY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(backKneeX, backKneeY))

                        val fThighX = (hipX + frontKneeX) / 2f
                        val fThighY = (hipY + frontKneeY) / 2f
                        val bThighX = (hipX + backKneeX) / 2f
                        val bThighY = (hipY + backKneeY) / 2f

                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.65f),
                            radius = pulseRadius * 1.05f,
                            center = Offset(fThighX, fThighY)
                        )
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.5f),
                            radius = pulseRadius * 1.0f,
                            center = Offset(bThighX, bThighY)
                        )
                    }

                    // ---- 12. CALF RAISES ----
                    nameLower.contains("calf") -> {
                        val liftFactor = animationProgress
                        val heelElevY = liftFactor * 15.dp.toPx()

                        val feetX = centerX
                        val feetY = centerY + 50.dp.toPx()
                        val hipY = centerY + 12.dp.toPx() - heelElevY
                        val shoulderY = centerY - 25.dp.toPx() - heelElevY
                        val headY = centerY - 45.dp.toPx() - heelElevY

                        drawLine(color = limbColor, start = Offset(feetX, feetY - heelElevY), end = Offset(feetX, hipY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(feetX, hipY), end = Offset(feetX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(feetX, headY))

                        val calfY = (centerY + 32.dp.toPx() - heelElevY)
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                            radius = pulseRadius * 1.15f,
                            center = Offset(feetX, calfY)
                        )

                        val heelY = feetY - heelElevY
                        drawLine(color = limbColor, start = Offset(feetX, heelY), end = Offset(feetX + 10.dp.toPx(), feetY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                    }

                    // ---- 13. CRUNCHES / ABDOMINALS ----
                    nameLower.contains("crunch") || nameLower.contains("ab") -> {
                        val crunchFactor = animationProgress
                        
                        val floorY = centerY + 42.dp.toPx()
                        val hipsX = centerX + 15.dp.toPx()

                        val shoulderX = centerX - 18.dp.toPx() + (crunchFactor * 24.dp.toPx())
                        val shoulderY = floorY - 5.dp.toPx() - (crunchFactor * 24.dp.toPx())
                        val headX = shoulderX - 16.dp.toPx() + (crunchFactor * 12.dp.toPx())
                        val headY = shoulderY - 14.dp.toPx()

                        val curvePath = Path().apply {
                            moveTo(hipsX, floorY)
                            quadraticTo(
                                (hipsX + shoulderX) / 2f + 5.dp.toPx() * (1f - crunchFactor),
                                (floorY + shoulderY) / 2f + 8.dp.toPx() * (crunchFactor),
                                shoulderX,
                                shoulderY
                            )
                        }
                        drawPath(path = curvePath, color = limbColor, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round))
                        drawCircle(color = primaryColor, radius = 10.dp.toPx(), center = Offset(headX, headY))

                        val kneeX = centerX + 45.dp.toPx()
                        val kneeY = centerY + 12.dp.toPx()
                        val footX = centerX + 60.dp.toPx()
                        drawLine(color = limbColor, start = Offset(hipsX, floorY), end = Offset(kneeX, kneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(kneeX, kneeY), end = Offset(footX, floorY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val handX = headX + 5.dp.toPx()
                        val handY = headY + 14.dp.toPx()
                        drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(handX, handY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)

                        val coreX = (hipsX + shoulderX) / 2f
                        val coreY = (floorY + shoulderY) / 2f
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.75f),
                            radius = pulseRadius * 1.35f,
                            center = Offset(coreX, coreY)
                        )
                    }

                    // ---- 14. HEAVY STRENGTH PLANKS ----
                    nameLower.contains("plank") -> {
                        val shakeX = quickTremble * 1.5f
                        val shakeY = quickTremble * 1.0f

                        val groundY = centerY + 42.dp.toPx()
                        val toesX = centerX - 75.dp.toPx() + shakeX
                        val toesY = groundY + shakeY
                        
                        val elbowX = centerX + 30.dp.toPx() + shakeX
                        val elbowY = groundY + shakeY

                        val hipX = centerX - 30.dp.toPx() + shakeX
                        val hipY = groundY - 14.dp.toPx() + shakeY

                        val shoulderX = centerX + 25.dp.toPx() + shakeX
                        val shoulderY = groundY - 18.dp.toPx() + shakeY

                        val headX = centerX + 46.dp.toPx() + shakeX
                        val headY = groundY - 24.dp.toPx() + shakeY

                        drawLine(color = limbColor, start = Offset(toesX, toesY), end = Offset(shoulderX, shoulderY), strokeWidth = 6.5.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 10.5.dp.toPx(), center = Offset(headX, headY))

                        drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(elbowX + 15.dp.toPx(), elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val coreCenterX = (hipX + shoulderX) / 2f
                        val coreCenterY = (hipY + shoulderY) / 2f
                        drawCircle(color = lineGlowColor, radius = 30.dp.toPx(), center = Offset(coreCenterX, coreCenterY), style = Stroke(2.dp.toPx()))
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.75f),
                            radius = pulseRadius * 1.4f,
                            center = Offset(coreCenterX, coreCenterY)
                        )
                    }

                    // ---- 15. SKIPPING JUMP ROPE ----
                    nameLower.contains("skipping") || nameLower.contains("jump") || nameLower.contains("rope") || nameLower.contains("rassi") -> {
                        val jumpFactor = if (animationProgress > 0.5f) (animationProgress - 0.5f) * 25.dp.toPx() else 0f
                        val hipY = centerY + 12.dp.toPx() - jumpFactor
                        val shoulderY = centerY - 25.dp.toPx() - jumpFactor
                        val headY = centerY - 45.dp.toPx() - jumpFactor

                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX, shoulderY), strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        val legKneeY = hipY + 22.dp.toPx() + (if (jumpFactor > 0) 6.dp.toPx() else 0f)
                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX - 8.dp.toPx(), legKneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX + 8.dp.toPx(), legKneeY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX - 8.dp.toPx(), legKneeY), end = Offset(centerX - 6.dp.toPx(), legKneeY + 20.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX + 8.dp.toPx(), legKneeY), end = Offset(centerX + 6.dp.toPx(), legKneeY + 20.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val handLX = centerX - 25.dp.toPx()
                        val handRX = centerX + 25.dp.toPx()
                        val handsY = centerY + 2.dp.toPx() - jumpFactor
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(handLX, handsY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(handRX, handsY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)

                        val angle = continuousProgress * 2 * PI
                        val rx = 65.dp.toPx()
                        
                        for (i in 0..20) {
                            val ratio = i / 20f
                            val ropeAngle = ratio * PI
                            val ropeX = centerX - rx * cos(ropeAngle).toFloat()
                            val ropeY = (centerY - 5.dp.toPx()) + sin(angle).toFloat() * 85.dp.toPx() * sin(ropeAngle).toFloat()
                            if (i > 0) {
                                val prevRatio = (i - 1) / 20f
                                val prevRopeX = centerX - rx * cos(prevRatio).toFloat()
                                val prevRopeY = (centerY - 5.dp.toPx()) + sin(angle).toFloat() * 85.dp.toPx() * sin(prevRatio).toFloat()
                                drawLine(color = Color(0xFFFF9800), start = Offset(prevRopeX, prevRopeY), end = Offset(ropeX, ropeY), strokeWidth = 2.dp.toPx())
                            }
                        }

                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.65f),
                            radius = pulseRadius * 1.0f,
                            center = Offset(centerX, legKneeY + 10.dp.toPx())
                        )
                    }

                    // ---- 16. BICEP & HAMMER CURLS ----
                    nameLower.contains("curl") || nameLower.contains("bicep") || nameLower.contains("hammer") -> {
                        val isHammer = nameLower.contains("hammer")
                        val curlFactor = animationProgress
                        
                        val feetY = centerY + 50.dp.toPx()
                        val hipsY = centerY + 12.dp.toPx()
                        val shoulderY = centerY - 25.dp.toPx()

                        drawLine(color = limbColor, start = Offset(centerX, feetY), end = Offset(centerX, hipsY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX, hipsY), end = Offset(centerX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, centerY - 45.dp.toPx()))

                        listOf(-22.dp.toPx(), 22.dp.toPx()).forEach { sideOffset ->
                            val sX = centerX + sideOffset * 0.4f
                            val elbowX = centerX + sideOffset
                            val elbowY = centerY + 10.dp.toPx()

                            val handX = elbowX + sideOffset * 0.6f * curlFactor
                            val handY = elbowY - 38.dp.toPx() * (curlFactor) - (1f - curlFactor) * 10.dp.toPx()

                            drawLine(color = limbColor, start = Offset(sX, shoulderY), end = Offset(elbowX, elbowY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(color = accentColor, start = Offset(elbowX, elbowY), end = Offset(handX, handY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                            drawCircle(color = jointColor, radius = 3.dp.toPx(), center = Offset(elbowX, elbowY))

                            val bicepX = (sX + elbowX)/2f + sideOffset * 0.2f * curlFactor
                            val bicepY = (shoulderY + elbowY)/2f
                            drawCircle(
                                color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.7f),
                                radius = pulseRadius * 0.85f,
                                center = Offset(bicepX, bicepY)
                            )

                            if (isHammer) {
                                drawLine(color = weightColor, start = Offset(handX, handY - 14.dp.toPx()), end = Offset(handX, handY + 14.dp.toPx()), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                                drawCircle(color = Color.White, radius = 7.dp.toPx(), center = Offset(handX, handY - 14.dp.toPx()))
                                drawCircle(color = Color.White, radius = 7.dp.toPx(), center = Offset(handX, handY + 14.dp.toPx()))
                            } else {
                                drawLine(color = weightColor, start = Offset(handX - 14.dp.toPx(), handY), end = Offset(handX + 14.dp.toPx(), handY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                                drawCircle(color = Color.White, radius = 7.dp.toPx(), center = Offset(handX - 14.dp.toPx(), handY))
                                drawCircle(color = Color.White, radius = 7.dp.toPx(), center = Offset(handX + 14.dp.toPx(), handY))
                            }
                        }
                    }

                    // ---- 17. THERAPEUTIC LIGHT STRETCHING ----
                    nameLower.contains("stretch") || nameLower.contains("stretching") -> {
                        val stretchFactor = animationProgress
                        
                        val feetX = centerX
                        val feetY = centerY + 50.dp.toPx()

                        val hipX = centerX - stretchFactor * 24.dp.toPx()
                        val hipY = centerY + 12.dp.toPx() + stretchFactor * 10.dp.toPx()

                        val shoulderX = centerX - stretchFactor * 44.dp.toPx()
                        val shoulderY = (centerY - 25.dp.toPx()) + stretchFactor * 55.dp.toPx()
                        
                        val headX = shoulderX + (if (stretchFactor > 0.5f) 8.dp.toPx() else 0f)
                        val headY = shoulderY - 15.dp.toPx()

                        drawLine(color = limbColor, start = Offset(feetX, feetY), end = Offset(hipX, hipY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val spinePath = Path().apply {
                            moveTo(hipX, hipY)
                            quadraticTo(
                                (hipX + shoulderX)/2f - 10.dp.toPx() * (stretchFactor),
                                (hipY + shoulderY)/2f,
                                shoulderX,
                                shoulderY
                            )
                        }
                        drawPath(path = spinePath, color = limbColor, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round))
                        drawCircle(color = primaryColor, radius = 10.5.dp.toPx(), center = Offset(headX, headY))

                        val handX = shoulderX - (1f - stretchFactor) * 8.dp.toPx() + (stretchFactor * 12.dp.toPx())
                        val handY = shoulderY + (if (stretchFactor > 0.5f) 16.dp.toPx() else (-45.dp.toPx()))

                        drawLine(color = accentColor, start = Offset(shoulderX, shoulderY), end = Offset(handX, handY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)

                        val hamX = (feetX + hipX) / 2f
                        val hamY = (feetY + hipY) / 2f
                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.6f),
                            radius = pulseRadius * 1.15f,
                            center = Offset(hamX, hamY)
                        )
                    }

                    // ---- 18. DEFAULT UNIVERSAL ACTIVE JACKS ----
                    else -> {
                        val activeFactor = animationProgress
                        val feetY = centerY + 50.dp.toPx()

                        val limbSpread = activeFactor * 25.dp.toPx()
                        val hipY = centerY + 12.dp.toPx()
                        val shoulderY = centerY - 25.dp.toPx()
                        val headY = centerY - 45.dp.toPx()

                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX, shoulderY), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
                        drawCircle(color = primaryColor, radius = 11.dp.toPx(), center = Offset(centerX, headY))

                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX - limbSpread, feetY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = limbColor, start = Offset(centerX, hipY), end = Offset(centerX + limbSpread, feetY), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)

                        val handY = shoulderY - (activeFactor * 35.dp.toPx()) + (1f - activeFactor) * 20.dp.toPx()
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(centerX - limbSpread - 10.dp.toPx(), handY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        drawLine(color = accentColor, start = Offset(centerX, shoulderY), end = Offset(centerX + limbSpread + 10.dp.toPx(), handY), strokeWidth = 4.5.dp.toPx(), cap = StrokeCap.Round)

                        drawCircle(
                            color = Color(0xFFFF3333).copy(alpha = pulseAlpha * 0.5f),
                            radius = pulseRadius * 1.25f,
                            center = Offset(centerX, centerY - 6.dp.toPx())
                        )
                    }
                }
            }

            // Top Left HUD tag
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color(0xFF161518).copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .background(Color(0xFF22C55E), shape = CircleShape)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "LOCKED-ON SCANNER",
                    color = Color.LightGray,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Top Right HUD tag for Target Muscle
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color(0xFFFF3333).copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFFF3333).copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(Color(0xFFFF3333).copy(alpha = pulseAlpha), shape = CircleShape)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = targetMuscle.uppercase(),
                    color = Color(0xFFFCA5A5),
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
        
        Text(
            text = "BIOMECHANIC MOTION ANALYSER",
            color = Color(0xFFF97316),
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(bottom = 12.dp)
        )
    }
}

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ExerciseLog
import com.example.ui.viewmodel.Routine
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    routine: Routine?,
    todayLogs: List<ExerciseLog>,
    onStartWorkoutResume: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var countdownText by remember { mutableStateOf("00:00:00") }

    LaunchedEffect(Unit) {
        while (true) {
            val now = java.util.Calendar.getInstance()
            val endOfDay = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 23)
                set(java.util.Calendar.MINUTE, 59)
                set(java.util.Calendar.SECOND, 59)
                set(java.util.Calendar.MILLISECOND, 999)
            }
            val diff = endOfDay.timeInMillis - now.timeInMillis
            if (diff > 0) {
                val hours = (diff / (3600 * 1000))
                val minutes = (diff / (60 * 1000)) % 60
                val seconds = (diff / 1000) % 60
                countdownText = String.format("%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                countdownText = "00:00:00"
            }
            delay(1000)
        }
    }

    // Calculations of completed exercises and remaining
    val exercises = routine?.exercises ?: emptyList()
    var completedExercisesCount = 0
    var remainingExercisesCount = 0

    val exerciseProgressList = exercises.map { exercise ->
        val loggedSetsForThisEx = todayLogs.filter { it.exerciseName == exercise.name }
        val completedSetsSet = loggedSetsForThisEx.map { it.setsCompleted }.toSet()
        val numCompletedSets = completedSetsSet.size
        val isCompleted = numCompletedSets >= exercise.sets

        if (isCompleted) {
            completedExercisesCount++
        } else {
            remainingExercisesCount++
        }

        Triple(exercise, numCompletedSets, isCompleted)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Futuristic Clean English Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "DOMINATE THE DAY",
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Stronger Together 💪",
                    color = Color(0xFFE2E2E6),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
            }
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Star,
                    contentDescription = "Achievements",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Countdown Timer Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF1C1B1F), Color(0xFF111318))
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .border(1.dp, Color(0xFF49454F).copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(20.dp)
                .testTag("time_left_ticker_card")
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Timer,
                        contentDescription = "Clock",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TIME LEFT TO SMASH GOALS",
                        color = Color(0xFFC4C6CF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = countdownText,
                    color = Color(0xFFE2E2E6),
                    fontSize = 40.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Dynamic Exercise Completion Summary Text Block
        val summaryTitle: String
        val summarySubtitle: String

        if (exercises.isEmpty()) {
            summaryTitle = "Active Rest Day"
            summarySubtitle = "No exercises scheduled for today. Rest and recover!"
        } else {
            summaryTitle = "Today's Target Overview"
            summarySubtitle = if (remainingExercisesCount == 0) {
                "All workouts complete! Excellent work today."
            } else {
                val completionWord = if (completedExercisesCount == 1) "exercise" else "exercises"
                val remainingWord = if (remainingExercisesCount == 1) "exercise remaining" else "exercises left"
                "$completedExercisesCount $completionWord completed and $remainingExercisesCount $remainingWord"
            }
        }

        // Section Title & Progress Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DAILY TARGETS PROGRESS",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = summarySubtitle,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (exercises.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Rest Day. Muscle recovery in progress.",
                        color = Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            // Exercise Set Tracker interactive item list representation
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(exerciseProgressList) { index, item ->
                    val ex = item.first
                    val numDone = item.second
                    val isDone = item.third

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDone) MaterialTheme.colorScheme.primary.copy(alpha = 0.04f) else Color(0xFF1C1B1F)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (isDone) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color(0xFF49454F).copy(alpha = 0.4f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onStartWorkoutResume(index) }
                            .testTag("home_exercise_progress_card_$index")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ex.name,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Set-by-Set Visual Checklist tracker dots
                                    for (setNum in 1..ex.sets) {
                                        val isSetDone = todayLogs.any { it.exerciseName == ex.name && it.setsCompleted == setNum }
                                        Box(
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(
                                                    if (isSetDone) MaterialTheme.colorScheme.primary else Color(0xFF2B2930)
                                                )
                                                .border(1.dp, Color(0xFF49454F), RoundedCornerShape(4.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "$setNum",
                                                color = if (isSetDone) Color(0xFF381E72) else Color.Gray,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "$numDone/${ex.sets} Sets Done",
                                        color = if (isDone) Color(0xFF22C55E) else Color.LightGray,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Dynamic action indicator
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(
                                        if (isDone) Color(0x3322C55E) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                        RoundedCornerShape(50)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = "All sets completed",
                                        tint = Color(0xFF22C55E),
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = "Resume standard exercise",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Professional Clean Motivational Quote Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141218)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF49454F).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🔥",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(end = 10.dp)
                )
                Column {
                    Text(
                        text = "Consistency is the Ultimate Key",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Stay disciplined to achieve your dream physique. Keep moving!",
                        color = Color(0xFFC4C6CF),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

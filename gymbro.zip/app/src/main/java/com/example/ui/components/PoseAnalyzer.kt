package com.example.ui.components

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions

class PoseAnalyzer(
    private val onPoseDetected: (Pose, Int, Int) -> Unit,
    private val onMotion: (Boolean) -> Unit,
    private val onRep: () -> Unit
) : ImageAnalysis.Analyzer {

    private val options = PoseDetectorOptions.Builder()
        .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
        .build()

    private val poseDetector = PoseDetection.getClient(options)

    private var lastLuminance: Double? = null
    private var lastTriggerTime = 0L
    private var state = "stable"
    private val threshold = 3.2

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            // Y-Channel logic for rep counting
            try {
                val planeY = imageProxy.planes[0]
                val buffer = planeY.buffer
                val data = ByteArray(buffer.remaining())
                buffer.get(data)
                // We need to restore buffer position for ML Kit if it uses it directly (it shouldn't but just in case)
                buffer.rewind()
                
                val width = imageProxy.width
                val height = imageProxy.height
                val boxWidth = 100
                val boxHeight = 100
                val startX = (width - boxWidth) / 2
                val startY = (height - boxHeight) / 2

                var sum = 0.0
                var pixelCount = 0

                val rowStride = planeY.rowStride
                val pixelStride = planeY.pixelStride

                for (y in startY until (startY + boxHeight) step 2) {
                    for (x in startX until (startX + boxWidth) step 2) {
                        val index = y * rowStride + x * pixelStride
                        if (index < data.size) {
                            sum += data[index].toInt() and 0xFF
                            pixelCount++
                        }
                    }
                }

                val currentLuminance = if (pixelCount > 0) sum / pixelCount else 0.0
                val now = System.currentTimeMillis()

                if (lastLuminance != null) {
                    val diff = Math.abs(currentLuminance - lastLuminance!!)
                    val isMotion = diff > threshold

                    onMotion(isMotion)

                    if (isMotion) {
                        if (state == "stable" && (now - lastTriggerTime > 1000)) {
                            state = "active"
                            lastTriggerTime = now
                            onRep()
                        }
                    } else {
                        if (state == "active" && (now - lastTriggerTime > 400)) {
                            state = "stable"
                        }
                    }
                }
                lastLuminance = currentLuminance
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // ML Kit logic
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            poseDetector.process(image)
                .addOnSuccessListener { pose ->
                    onPoseDetected(pose, image.width, image.height)
                }
                .addOnFailureListener {
                    // Handle error
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
}


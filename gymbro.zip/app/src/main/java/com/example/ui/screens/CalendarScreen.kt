package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DailyProgress
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CalendarScreen(
    allProgress: List<DailyProgress>,
    modifier: Modifier = Modifier
) {
    // Current Calendar Month Config
    val calendar = remember { Calendar.getInstance() }
    val currentMonthIdx = remember { calendar.get(Calendar.MONTH) }
    val currentYear = remember { calendar.get(Calendar.YEAR) }
    val currentDayOfMonth = remember { calendar.get(Calendar.DAY_OF_MONTH) }

    val monthNames = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    // Calculate details for grid
    val maxDays = remember { calendar.getActualMaximum(Calendar.DAY_OF_MONTH) }
    val calendarHelper = remember { Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) } }
    val firstDayOfWeekOffset = remember { calendarHelper.get(Calendar.DAY_OF_WEEK) - 1 } // Sunday = 0, Mon = 1, etc.

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Headers
        Text(
            text = "PROGRESS TRACKER",
            color = Color.Gray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.Start)
        )
        Text(
            text = "${monthNames[currentMonthIdx]} $currentYear",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Grids Weekday Headers
        val gridHeaders = listOf("S", "M", "T", "W", "T", "F", "S")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            gridHeaders.forEach { header ->
                Text(
                    text = header,
                    color = Color.Gray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Monthly Grid Calculation
        val totalCells = firstDayOfWeekOffset + maxDays
        val rows = if (totalCells % 7 == 0) totalCells / 7 else (totalCells / 7) + 1

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1C1B1F), RoundedCornerShape(24.dp))
                .border(1.dp, Color(0xFF49454F).copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(12.dp)
        ) {
            for (r in 0 until rows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNumber = cellIndex - firstDayOfWeekOffset + 1

                        if (dayNumber in 1..maxDays) {
                            val isPastOrPresent = dayNumber <= currentDayOfMonth

                            // Base cell cellBg and borders
                            val cellBg = Color.Transparent
                            val cellBorder = Color.Transparent

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(cellBg)
                                    .border(1.dp, cellBorder, RoundedCornerShape(12.dp))
                                    .then(
                                        if (isPastOrPresent) {
                                            // Disabled clicking for past and present dates as requested
                                            Modifier
                                        } else {
                                            // Future dates can have click interactions if needed
                                            Modifier.clickable { /* no-op */ }
                                        }
                                    )
                                    .testTag("calendar_day_$dayNumber"),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    // 1. Thin clearly visible Red Cross for past & present dates (automatic)
                                    if (isPastOrPresent) {
                                        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
                                            // Thin diagonal 1
                                            drawLine(
                                                color = Color(0xFFFF3B30),
                                                start = Offset(0f, 0f),
                                                end = Offset(size.width, size.height),
                                                strokeWidth = 1.5.dp.toPx()
                                            )
                                            // Thin diagonal 2
                                            drawLine(
                                                color = Color(0xFFFF3B30),
                                                start = Offset(size.width, 0f),
                                                end = Offset(0f, size.height),
                                                strokeWidth = 1.5.dp.toPx()
                                            )
                                        }
                                    }

                                    // 2. Clear Date text rendered ON TOP of the cross mark
                                    Text(
                                        text = "$dayNumber",
                                        color = if (isPastOrPresent) Color.White.copy(alpha = 0.8f) else Color.LightGray,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Box(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        
        // Compact visual guidelines legend
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141218)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF49454F).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📅", fontSize = 20.sp, modifier = Modifier.padding(end = 12.dp))
                Column {
                    Text(
                        text = "Auto-Closed Calendar",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "All past and present dates are automatically locked & closed.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import android.media.MediaPlayer
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DailyProgress
import com.example.data.local.ExerciseLog
import com.example.data.repository.GymBroRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

sealed class WorkoutState {
    object Idle : WorkoutState()
    object CorePrep : WorkoutState()
    object Exercising : WorkoutState()
    object Resting : WorkoutState()
    object Completed : WorkoutState()
}

data class Exercise(
    val name: String,
    val scheduledTime: String,
    val sets: Int,
    val reps: String, // e.g. "15", "10-12", "Max", "3 Mins"
    val rest: Int, // seconds
    val type: String // "reps" or "time"
)

data class Routine(
    val type: String,
    val bestTime: String,
    val exercises: List<Exercise>
)

class GymBroViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GymBroRepository(
        AppDatabase.getDatabase(application).dailyProgressDao(),
        AppDatabase.getDatabase(application).exerciseLogDao()
    )
    private val prefs = application.getSharedPreferences("gymbro_app_prefs", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null

    fun speakText(text: String) {
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Tab State
    private val _currentTab = MutableStateFlow("home")
    val currentTab = _currentTab.asStateFlow()

    fun setCurrentTab(tab: String) {
        _currentTab.value = tab
    }

    // Date Management
    private val dbDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private val _todayDate = MutableStateFlow(dbDateFormat.format(Date()))
    val todayDate = _todayDate.asStateFlow()

    private val _selectedDate = MutableStateFlow(dbDateFormat.format(Date()))
    val selectedDate = _selectedDate.asStateFlow()

    // Week day selector e.g. "Monday"
    private val _selectedDayOfWeek = MutableStateFlow(SimpleDateFormat("EEEE", Locale.US).format(Date()))
    val selectedDayOfWeek = _selectedDayOfWeek.asStateFlow()

    fun selectDayOfWeek(day: String) {
        _selectedDayOfWeek.value = day
    }

    fun selectDate(dateStr: String) {
        _selectedDate.value = dateStr
        // Update weekday accordingly
        try {
            val date = dbDateFormat.parse(dateStr)
            if (date != null) {
                _selectedDayOfWeek.value = SimpleDateFormat("EEEE", Locale.US).format(date)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        loadWaterSlotsForDate(dateStr)
    }

    // Database reactive updates
    val selectedDayProgress: StateFlow<DailyProgress?> = _selectedDate
        .flatMapLatest { date -> repository.getProgressByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allProgressList: StateFlow<List<DailyProgress>> = repository.allDailyProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Day's Exercise Logs
    val selectedDayExerciseLogs: StateFlow<List<ExerciseLog>> = _selectedDate
        .flatMapLatest { date -> repository.getExerciseLogsByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Update methods
    fun toggleWorkoutCompleted(date: String, completed: Boolean) {
        viewModelScope.launch {
            repository.updateWorkoutCompletion(date, completed)
        }
    }

    // Clean, English-Only schedule definition
    val workoutSchedules = mapOf(
        "Monday" to Routine(
            type = "Chest & Triceps (Push Day)",
            bestTime = "Evening (5:00 PM - 7:00 PM)",
            exercises = listOf(
                Exercise("Jump Rope", "05:00 PM", 1, "3 Mins", 60, "time"),
                Exercise("Standard Pushups", "05:10 PM", 3, "15", 60, "reps"),
                Exercise("Dumbbell Floor Press", "05:20 PM", 3, "12", 60, "reps"),
                Exercise("Diamond Pushups", "05:30 PM", 3, "10-12", 60, "reps"),
                Exercise("Tricep Extension", "05:40 PM", 3, "12", 60, "reps")
            )
        ),
        "Tuesday" to Routine(
            type = "Back & Biceps (Pull Day)",
            bestTime = "Evening (5:00 PM - 8:00 PM)",
            exercises = listOf(
                Exercise("Jump Rope", "05:00 PM", 1, "3 Mins", 60, "time"),
                Exercise("Pull-ups (Home Bar)", "05:10 PM", 4, "Max", 90, "reps"),
                Exercise("Dumbbell Rows", "05:25 PM", 3, "12", 60, "reps"),
                Exercise("Chin-ups", "05:40 PM", 3, "8-10", 90, "reps"),
                Exercise("Bicep Curls", "05:50 PM", 3, "12-15", 60, "reps")
            )
        ),
        "Wednesday" to Routine(
            type = "Legs & Core",
            bestTime = "Evening (6:00 PM - 8:00 PM)",
            exercises = listOf(
                Exercise("Jump Rope", "06:00 PM", 1, "5 Mins", 60, "time"),
                Exercise("Goblet Squats", "06:10 PM", 4, "15", 90, "reps"),
                Exercise("Dumbbell Lunges", "06:25 PM", 3, "12", 60, "reps"),
                Exercise("Calf Raises", "06:40 PM", 4, "20", 45, "reps"),
                Exercise("Crunches", "06:50 PM", 3, "20", 45, "reps"),
                Exercise("Plank Hold", "07:00 PM", 3, "60 Secs", 60, "time")
            )
        ),
        "Thursday" to Routine(
            type = "Shoulders & Traps",
            bestTime = "Morning (7:00 AM - 9:00 AM)",
            exercises = listOf(
                Exercise("Jump Rope", "07:00 AM", 1, "3 Mins", 60, "time"),
                Exercise("Pike Pushups", "07:10 AM", 3, "10-12", 60, "reps"),
                Exercise("Overhead Press", "07:20 AM", 3, "10", 60, "reps"),
                Exercise("Dumbbell Shrugs", "07:30 AM", 3, "15-20", 45, "reps")
            )
        ),
        "Friday" to Routine(
            type = "Full Upper Body (Mix)",
            bestTime = "Evening (5:00 PM - 7:00 PM)",
            exercises = listOf(
                Exercise("Pull-ups", "05:00 PM", 3, "Max", 90, "reps"),
                Exercise("Standard Pushups", "05:15 PM", 3, "Max", 60, "reps"),
                Exercise("Hammer Curls", "05:30 PM", 3, "12", 60, "reps"),
                Exercise("Floor Press", "05:40 PM", 3, "12", 60, "reps")
            )
        ),
        "Saturday" to Routine(
            type = "Cardio & Abs Fat Burn",
            bestTime = "Morning Empty Stomach (6:00 AM)",
            exercises = listOf(
                Exercise("Jump Rope", "06:00 AM", 5, "2 Mins", 30, "time"),
                Exercise("Hanging Leg Raises", "06:20 AM", 3, "10-15", 60, "reps"),
                Exercise("Crunches", "06:35 AM", 3, "20", 45, "reps")
            )
        ),
        "Sunday" to Routine(
            type = "Rest & Active Recovery",
            bestTime = "Anytime after waking up",
            exercises = listOf(
                Exercise("Light Stretching", "08:00 AM", 1, "10 Mins", 0, "time"),
                Exercise("Walk", "08:15 AM", 1, "20 Mins", 0, "time")
            )
        )
    )

    // Current active playing states
    private val _activeWorkoutState = MutableStateFlow<WorkoutState>(WorkoutState.Idle)
    val activeWorkoutState = _activeWorkoutState.asStateFlow()

    private val _activeExIndex = MutableStateFlow(0)
    val activeExIndex = _activeExIndex.asStateFlow()

    private val _activeSetNum = MutableStateFlow(1)
    val activeSetNum = _activeSetNum.asStateFlow()

    private val _restTimeRemaining = MutableStateFlow(0)
    val restTimeRemaining = _restTimeRemaining.asStateFlow()

    private val _activeExTimeRemaining = MutableStateFlow<Int?>(null)
    val activeExTimeRemaining = _activeExTimeRemaining.asStateFlow()

    private val _isTimeExerciseRunning = MutableStateFlow(false)
    val isTimeExerciseRunning = _isTimeExerciseRunning.asStateFlow()

    // 5-second camera prep countdown timer
    private val _prepTimeRemaining = MutableStateFlow<Int?>(null)
    val prepTimeRemaining = _prepTimeRemaining.asStateFlow()

    // Camera Motion tracker states
    private val _cameraReps = MutableStateFlow(0)
    val cameraReps = _cameraReps.asStateFlow()

    private val _isMotionActive = MutableStateFlow(false)
    val isMotionActive = _isMotionActive.asStateFlow()

    private var restJob: Job? = null
    private var exerciseTimerJob: Job? = null
    private var prepTimerJob: Job? = null

    // Start Specific Exercise
    fun startExercise(index: Int, setNum: Int) {
        _activeExIndex.value = index
        _activeSetNum.value = setNum
        _activeWorkoutState.value = WorkoutState.Exercising

        val currentRoutine = workoutSchedules[_selectedDayOfWeek.value] ?: workoutSchedules["Monday"]!!
        val ex = currentRoutine.exercises[index]

        _cameraReps.value = 0
        _isMotionActive.value = false
        _prepTimeRemaining.value = null

        if (ex.type == "time") {
            val seconds = if (ex.reps.contains("Min")) {
                (ex.reps.replace(" Mins", "").replace(" Min", "").trim().toIntOrNull() ?: 1) * 60
            } else if (ex.reps.contains("Sec")) {
                ex.reps.replace(" Secs", "").replace(" Sec", "").trim().toIntOrNull() ?: 60
            } else {
                60
            }
            _activeExTimeRemaining.value = seconds
            _isTimeExerciseRunning.value = false
        } else {
            _activeExTimeRemaining.value = null
            _isTimeExerciseRunning.value = false
        }
    }

    fun startPrepTimer(onFinish: () -> Unit) {
        prepTimerJob?.cancel()
        _prepTimeRemaining.value = 5
        prepTimerJob = viewModelScope.launch {
            while (_prepTimeRemaining.value != null && _prepTimeRemaining.value!! > 0) {
                delay(1000)
                _prepTimeRemaining.value = _prepTimeRemaining.value!! - 1
            }
            _prepTimeRemaining.value = null
            onFinish()
        }
    }

    fun toggleTimeExerciseTimer() {
        if (_isTimeExerciseRunning.value) {
            _isTimeExerciseRunning.value = false
            exerciseTimerJob?.cancel()
            speakText("Timer paused")
        } else {
            _isTimeExerciseRunning.value = true
            speakText("Timer started")
            exerciseTimerJob = viewModelScope.launch {
                while (_activeExTimeRemaining.value != null && _activeExTimeRemaining.value!! > 0) {
                    delay(1000)
                    _activeExTimeRemaining.value = _activeExTimeRemaining.value!! - 1
                }
                _isTimeExerciseRunning.value = false
                if (_activeExTimeRemaining.value == 0) {
                    completeSet()
                }
            }
        }
    }

    fun incrementCameraReps() {
        _cameraReps.value = _cameraReps.value + 1
        speakText("${_cameraReps.value}")
    }

    fun setMotionActive(active: Boolean) {
        _isMotionActive.value = active
    }

    fun completeSet() {
        val currentRoutine = workoutSchedules[_selectedDayOfWeek.value] ?: workoutSchedules["Monday"]!!
        val ex = currentRoutine.exercises[_activeExIndex.value]

        // Log session in Database
        val date = _todayDate.value
        viewModelScope.launch {
            repository.insertExerciseLog(
                ExerciseLog(
                    date = date,
                    exerciseName = ex.name,
                    repsCompleted = if (ex.type == "time") 0 else _cameraReps.value,
                    setsCompleted = _activeSetNum.value
                )
            )
        }

        _prepTimeRemaining.value = null
        prepTimerJob?.cancel()
        exerciseTimerJob?.cancel()
        _isTimeExerciseRunning.value = false

        if (_activeSetNum.value < ex.sets) {
            // Next Set
            speakText("Set ${_activeSetNum.value} completed! Please rest.")
            startRestTimer(ex.rest)
        } else {
            // All sets done
            if (_activeExIndex.value < currentRoutine.exercises.lastIndex) {
                speakText("Exercise ${ex.name} completed! Take rest.")
                startRestTimer(ex.rest)
            } else {
                // Complete workout!
                _activeWorkoutState.value = WorkoutState.Completed
                toggleWorkoutCompleted(_todayDate.value, true)
                speakText("Workout set completed! Outstanding job!")
            }
        }
    }

    private fun startRestTimer(seconds: Int) {
        restJob?.cancel()
        _activeWorkoutState.value = WorkoutState.Resting
        _restTimeRemaining.value = seconds
        speakText("Rest started. Take ${seconds} seconds rest.")
        restJob = viewModelScope.launch {
            while (_restTimeRemaining.value > 0) {
                delay(1000)
                _restTimeRemaining.value = _restTimeRemaining.value - 1
            }
            goToNextSet()
        }
    }

    fun skipRest() {
        _restTimeRemaining.value = 0
        restJob?.cancel()
        goToNextSet()
    }

    private fun goToNextSet() {
        val currentRoutine = workoutSchedules[_selectedDayOfWeek.value] ?: workoutSchedules["Monday"]!!
        val ex = currentRoutine.exercises[_activeExIndex.value]

        if (_activeSetNum.value < ex.sets) {
            startExercise(_activeExIndex.value, _activeSetNum.value + 1)
            speakText("Set ${_activeSetNum.value} started.")
        } else {
            val nextEx = currentRoutine.exercises.getOrNull(_activeExIndex.value + 1)
            startExercise(_activeExIndex.value + 1, 1)
            if (nextEx != null) {
                speakText("First set of ${nextEx.name} started.")
            }
        }
    }

    fun exitWorkout() {
        intentToResume = false
        exerciseTimerJob?.cancel()
        restJob?.cancel()
        prepTimerJob?.cancel()
        _activeWorkoutState.value = WorkoutState.Idle
    }

    // Smart auto resume helper variable
    var intentToResume = false

    // Smart Exercise Resume Flow (Resumes from the exact set of the target exercise)
    fun startExerciseWithResume(exIdx: Int) {
        val currentRoutine = workoutSchedules[_selectedDayOfWeek.value] ?: workoutSchedules["Monday"]!!
        val exercise = currentRoutine.exercises.getOrNull(exIdx) ?: return

        // Find logged sets for this exact exercise today to resume from the lowest incomplete one
        val logs = selectedDayExerciseLogs.value.filter { it.exerciseName == exercise.name }
        val completedSets = logs.map { it.setsCompleted }.toSet()

        var nextSetToStart = 1
        for (set in 1..exercise.sets) {
            if (set !in completedSets) {
                nextSetToStart = set
                break
            }
        }

        startExercise(exIdx, nextSetToStart)
    }

    // Music Player Controller - Permanent custom upload/delete structure
    private val _songsList = MutableStateFlow<List<Triple<String, String, String>>>(emptyList())
    val songsList = _songsList.asStateFlow()

    private fun loadSongs() {
        val customStr = prefs.getString("custom_uploaded_songs", "") ?: ""
        val customSongs = if (customStr.isNotEmpty()) {
            customStr.split(";;").mapNotNull { part ->
                val pieces = part.split("|")
                if (pieces.size >= 3) {
                    Triple(pieces[0], pieces[1], pieces[2])
                } else if (pieces.size == 2) {
                    Triple(pieces[0], pieces[1], "")
                } else null
            }
        } else {
            emptyList()
        }
        _songsList.value = customSongs
    }

    private fun saveSongsToPrefs(songs: List<Triple<String, String, String>>) {
        val serializedString = songs.joinToString(";;") { "${it.first}|${it.second}|${it.third}" }
        prefs.edit().putString("custom_uploaded_songs", serializedString).apply()
    }

    fun uploadCustomSong(name: String, genre: String, uriString: String) {
        val current = _songsList.value.toMutableList()
        current.add(Triple(name, genre, uriString))
        _songsList.value = current
        saveSongsToPrefs(current)
        if (current.size == 1) {
            _currentSongIdx.value = 0
        }
    }

    fun deleteCustomSong(index: Int) {
        val current = _songsList.value.toMutableList()
        if (index in current.indices) {
            if (index == _currentSongIdx.value && _isPlayingSong.value) {
                try {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null
                    _isPlayingSong.value = false
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            current.removeAt(index)
            _songsList.value = current
            saveSongsToPrefs(current)
            
            // Adjust index to prevent out-of-bounds error
            if (_currentSongIdx.value >= current.size) {
                _currentSongIdx.value = maxOf(0, current.size - 1)
            }

            if (_isPlayingSong.value && current.isNotEmpty()) {
                playSong(current[_currentSongIdx.value].third)
            }
        }
    }

    private val _isPlayingSong = MutableStateFlow(false)
    val isPlayingSong = _isPlayingSong.asStateFlow()

    private val _currentSongIdx = MutableStateFlow(0)
    val currentSongIdx = _currentSongIdx.asStateFlow()

    fun playSong(uriString: String) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null

            if (uriString.isEmpty()) return

            val uri = Uri.parse(uriString)

            try {
                val contentResolver = getApplication<Application>().contentResolver
                contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore if permission already present or non-persistable scheme
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(getApplication(), uri)
                prepare()
                isLooping = true
                start()
            }
            _isPlayingSong.value = true
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlayingSong.value = false
        }
    }

    fun toggleSongPlay() {
        try {
            val player = mediaPlayer
            if (player != null) {
                if (player.isPlaying) {
                    player.pause()
                    _isPlayingSong.value = false
                } else {
                    player.start()
                    _isPlayingSong.value = true
                }
            } else {
                val current = _songsList.value.getOrNull(_currentSongIdx.value)
                if (current != null && current.third.isNotEmpty()) {
                    playSong(current.third)
                } else {
                    _isPlayingSong.value = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlayingSong.value = false
        }
    }

    fun playNextSong() {
        val total = _songsList.value.size
        if (total > 0) {
            _currentSongIdx.value = (_currentSongIdx.value + 1) % total
            playSong(_songsList.value[_currentSongIdx.value].third)
        }
    }

    fun playPrevSong() {
        val total = _songsList.value.size
        if (total > 0) {
            _currentSongIdx.value = (_currentSongIdx.value - 1 + total) % total
            playSong(_songsList.value[_currentSongIdx.value].third)
        }
    }

    fun selectSong(idx: Int) {
        if (idx in _songsList.value.indices) {
            _currentSongIdx.value = idx
            playSong(_songsList.value[idx].third)
        }
    }

    // Water Slots checked list management linked to SharedPreferences
    private val _checkedWaterSlots = MutableStateFlow<Set<String>>(emptySet())
    val checkedWaterSlots = _checkedWaterSlots.asStateFlow()

    fun loadWaterSlotsForDate(date: String) {
        val savedStr = prefs.getString("water_checked_slots_$date", "") ?: ""
        val slots = if (savedStr.isNotEmpty()) {
            savedStr.split(",").toSet()
        } else {
            emptySet()
        }
        _checkedWaterSlots.value = slots
    }

    fun toggleWaterSlot(slotId: String, checked: Boolean) {
        val date = _selectedDate.value
        val currentSlots = _checkedWaterSlots.value.toMutableSet()
        if (checked) {
            currentSlots.add(slotId)
        } else {
            currentSlots.remove(slotId)
        }
        _checkedWaterSlots.value = currentSlots

        val serialized = currentSlots.joinToString(",")
        prefs.edit().putString("water_checked_slots_$date", serialized).apply()

        // 3250ml total allocation target:
        val slotAmountMap = mapOf(
            "slot_0" to 500,
            "slot_1" to 750,
            "slot_2" to 500,
            "slot_3" to 750,
            "slot_4" to 500,
            "slot_5" to 250
        )
        val totalMl = currentSlots.sumOf { slotAmountMap[it] ?: 0 }

        viewModelScope.launch {
            repository.updateWaterIntake(date, totalMl)
        }
    }

    // Update Water ML manually (e.g. from calendar backup override)
    fun updateWaterMl(date: String, ml: Int) {
        viewModelScope.launch {
            repository.updateWaterIntake(date, ml)
        }
    }

    init {
        tts = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
        loadSongs()
        loadWaterSlotsForDate(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
    }
}

class GymBroViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GymBroViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GymBroViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

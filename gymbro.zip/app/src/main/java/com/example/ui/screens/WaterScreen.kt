package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class WaterSlot(
    val id: String,
    val timeLabel: String,
    val amountMl: Int,
    val timeWindow: String,
    val recommendation: String
)

@Composable
fun WaterScreen(
    currentWaterMl: Int,
    checkedSlots: Set<String>,
    onToggleSlot: (WaterSlot, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val waterSlots = listOf(
        WaterSlot("slot_0", "07:00 AM", 500, "7:00 AM - 8:30 AM", "Wake-up Hydration to kickstart metabolism"),
        WaterSlot("slot_1", "09:00 AM", 750, "9:00 AM - 11:30 AM", "Morning productivity boost hydration"),
        WaterSlot("slot_2", "12:30 PM", 500, "12:30 PM - 2:00 PM", "Pre/Post Lunch cellular hydration and digestion support"),
        WaterSlot("slot_3", "03:30 PM", 750, "3:30 PM - 5:30 PM", "Pre-workout energy optimization fluids"),
        WaterSlot("slot_4", "06:00 PM", 500, "6:00 PM - 7:30 PM", "Hydration during/after evening training zone"),
        WaterSlot("slot_5", "09:00 PM", 250, "9:00 PM - 10:30 PM", "Night wind-down recovery baseline hydration")
    )

    val targetWaterMl = 3250 // Average of 3L - 3.5L (3.25L)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Tracker Section Title
        Text(
            text = "HYDRATION MATRIX",
            color = Color(0xFFC4C6CF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.Start)
        )
        Text(
            text = "Water Schedule",
            color = Color(0xFFE2E2E6),
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Progress Overview Header Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TOTAL PROGRESS TODAY",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$currentWaterMl / $targetWaterMl ml",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress Indicator
                val progressFraction = (currentWaterMl.toFloat() / targetWaterMl.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0xFF2B2930)
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (progressFraction >= 1f) "Goal Reached! Excellent Hydration." else "Keep on drinking!",
                    color = Color(0xFFC4C6CF),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Subheader
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Text(
                text = "SCHEDULED WINDOWS",
                color = Color(0xFFC4C6CF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Scheduled Slots List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(waterSlots) { index, slot ->
                val isChecked = checkedSlots.contains(slot.id)
                val cardBg = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.05f) else Color(0xFF1C1B1F)
                val borderCol = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else Color(0xFF49454F).copy(alpha = 0.5f)

                Card(
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, borderCol, RoundedCornerShape(18.dp))
                        .clickable { onToggleSlot(slot, !isChecked) }
                        .testTag("water_slot_card_${slot.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            // Circular Indicator for amount
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(
                                        if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color(0xFF2B2930),
                                        RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${slot.amountMl}ml",
                                    color = if (isChecked) MaterialTheme.colorScheme.primary else Color(0xFFE2E2E6),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = slot.timeLabel,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Drink under: ${slot.timeWindow}",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = slot.recommendation,
                                    color = Color(0xFFC4C6CF),
                                    fontSize = 11.sp,
                                    lineHeight = 13.sp
                                )
                            }
                        }

                        // Completion check icon mark
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(
                                    if (isChecked) MaterialTheme.colorScheme.primary else Color(0xFF2B2930),
                                    RoundedCornerShape(50)
                                )
                                .border(
                                    1.dp,
                                    if (isChecked) Color.Transparent else Color(0xFF49454F).copy(alpha = 0.5f),
                                    RoundedCornerShape(50)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isChecked) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = Color(0xFF381E72),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.components

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraMotionTracker(
    exerciseName: String,
    targetReps: Int,
    currentSetNum: Int,
    totalSets: Int,
    onRepCounted: () -> Unit,
    onSetCompleted: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)

    var cameraLensFacing by remember { mutableStateOf<Int>(CameraSelector.LENS_FACING_FRONT) }
    var isCameraReady by remember { mutableStateOf(false) }
    var isMotionDetected by remember { mutableStateOf(false) }
    var detectedReps by remember { mutableStateOf(0) }

    // Start 5-second preparation countdown overlay
    var prepCountdown by remember { mutableStateOf(5) }
    
    // Auto-decrement countdown
    LaunchedEffect(prepCountdown) {
        if (prepCountdown > 0) {
            kotlinx.coroutines.delay(1000)
            prepCountdown--
        }
    }

    LaunchedEffect(Unit) {
        if (!cameraPermissionState.status.isGranted) {
            cameraPermissionState.launchPermissionRequest()
        }
    }

    if (!cameraPermissionState.status.isGranted) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Camera Permission Required",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Camera capability is used for detecting motion and automatically counting repetitions.",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { cameraPermissionState.launchPermissionRequest() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316))
                ) {
                    Text("Grant Permission", color = Color.White)
                }
            }
        }
    } else {
        Box(modifier = Modifier.fillMaxSize()) {
            val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
            val executorService = remember { Executors.newSingleThreadExecutor() }

            // Camera preview container
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }

                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val cameraSelector = CameraSelector.Builder()
                            .requireLensFacing(cameraLensFacing)
                            .build()

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        imageAnalysis.setAnalyzer(executorService, MotionAnalyzer(
                            onMotion = { motion ->
                                isMotionDetected = motion
                            },
                            onRep = {
                                if (prepCountdown == 0) {
                                    detectedReps++
                                    onRepCounted()
                                    if (detectedReps >= targetReps) {
                                        onSetCompleted()
                                    }
                                }
                            }
                        ))

                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageAnalysis
                            )
                            isCameraReady = true
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize(),
                update = { previewView ->
                    // Handle lens flipping
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val cameraSelector = CameraSelector.Builder()
                            .requireLensFacing(cameraLensFacing)
                            .build()

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        imageAnalysis.setAnalyzer(executorService, MotionAnalyzer(
                            onMotion = { motion -> isMotionDetected = motion },
                            onRep = {
                                if (prepCountdown == 0) {
                                    detectedReps++
                                    onRepCounted()
                                    if (detectedReps >= targetReps) {
                                        onSetCompleted()
                                    }
                                }
                            }
                        ))

                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageAnalysis
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, ContextCompat.getMainExecutor(context))
                }
            )

            // Centered Target ROI Bounding Box
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.Center)
                    .border(
                        width = 4.dp,
                        color = if (isMotionDetected && prepCountdown == 0) Color(0xFF22C55E) else Color(0x80F97316),
                        shape = RoundedCornerShape(24.dp)
                    )
            )

            // Bottom camera controls
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xE0000000))
                    .padding(horizontal = 24.dp, vertical = 24.dp)
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = exerciseName,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFF97316), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("SET $currentSetNum/$totalSets", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Box(
                                modifier = Modifier
                                    .background(Color.White, shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("GOAL: $targetReps REPS", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Large glowing rep counter
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF0F0F0F), shape = RoundedCornerShape(16.dp))
                            .border(1.dp, Color(0xFF262626), shape = RoundedCornerShape(16.dp))
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$detectedReps",
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 36.sp
                            )
                            Text(
                                text = if (isMotionDetected && prepCountdown == 0) "MOTION" else "STABLE",
                                color = if (isMotionDetected && prepCountdown == 0) Color(0xFF22C55E) else Color(0xFFF97316),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Flip lens
                        IconButton(
                            onClick = {
                                cameraLensFacing = if (cameraLensFacing == CameraSelector.LENS_FACING_FRONT) {
                                    CameraSelector.LENS_FACING_BACK
                                } else {
                                    CameraSelector.LENS_FACING_FRONT
                                }
                            },
                            modifier = Modifier.background(Color(0xFF262626), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Switch Camera", tint = Color.White)
                        }

                        // Complete early
                        IconButton(
                            onClick = { onSetCompleted() },
                            modifier = Modifier.background(Color(0xFF22C55E), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.Done, contentDescription = "Done", tint = Color.White)
                        }
                    }
                }
            }

            // Top exit panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0xA0000000))
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .statusBarsPadding(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MOTION TRACKER ACTIVE",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                IconButton(
                    onClick = onExit,
                    modifier = Modifier.size(32.dp).background(Color(0x80000000), RoundedCornerShape(50))
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Camera", tint = Color.White)
                }
            }

            // High priority prep countdown overlay
            if (prepCountdown > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xE6000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$prepCountdown",
                            color = Color(0xFFF97316),
                            fontSize = 120.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 120.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "GET IN THE RED FRAME BOX!",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }
    }
}

// Low resource gray-scale Y-channel frame analyzer
private class MotionAnalyzer(
    private val onMotion: (Boolean) -> Unit,
    private val onRep: () -> Unit
) : ImageAnalysis.Analyzer {
    private var lastLuminance: Double? = null
    private var lastTriggerTime = 0L
    private var state = "stable" // "stable" or "active"
    private val threshold = 3.2

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val planeY = imageProxy.planes[0]
        val buffer = planeY.buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)

        val width = imageProxy.width
        val height = imageProxy.height

        // Define a central sub-sampled window coordinates of 100x100
        val boxWidth = 100
        val boxHeight = 100
        val startX = (width - boxWidth) / 2
        val startY = (height - boxHeight) / 2

        var sum = 0.0
        var pixelCount = 0

        val rowStride = planeY.rowStride
        val pixelStride = planeY.pixelStride

        for (y in startY until (startY + boxHeight) step 2) {
            for (x in startX until (startX + boxWidth) step 2) {
                val index = y * rowStride + x * pixelStride
                if (index < data.size) {
                    sum += data[index].toInt() and 0xFF
                    pixelCount++
                }
            }
        }

        val currentLuminance = if (pixelCount > 0) sum / pixelCount else 0.0
        val now = System.currentTimeMillis()

        if (lastLuminance != null) {
            val diff = Math.abs(currentLuminance - lastLuminance!!)
            val isMotion = diff > threshold

            onMotion(isMotion)

            if (isMotion) {
                // If it goes from fully stable to active and stays separated by at least 1000ms, it is 1 full motion rep!
                if (state == "stable" && (now - lastTriggerTime > 1000)) {
                    state = "active"
                    lastTriggerTime = now
                    onRep()
                }
            } else {
                if (state == "active" && (now - lastTriggerTime > 400)) {
                    state = "stable"
                }
            }
        }

        lastLuminance = currentLuminance
        imageProxy.close()
    }
}

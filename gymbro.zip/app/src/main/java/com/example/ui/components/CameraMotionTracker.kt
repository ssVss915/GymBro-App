package com.example.ui.components

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraMotionTracker(
    exerciseName: String,
    targetReps: Int,
    currentSetNum: Int,
    totalSets: Int,
    onRepCounted: () -> Unit,
    onSetCompleted: () -> Unit,
    onExit: () -> Unit,
    onSpeakRequested: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)

    var cameraLensFacing by remember { mutableStateOf<Int>(CameraSelector.LENS_FACING_FRONT) }
    var isCameraReady by remember { mutableStateOf(false) }
    var isMotionDetected by remember { mutableStateOf(false) }
    var detectedReps by remember { mutableStateOf(0) }
    var motionPulseCount by remember { mutableStateOf(0) }
    
    var detectedPose by remember { mutableStateOf<com.google.mlkit.vision.pose.Pose?>(null) }
    var imageWidth by remember { mutableStateOf(1) }
    var imageHeight by remember { mutableStateOf(1) }

    // Start 5-second preparation countdown overlay
    var prepCountdown by remember { mutableStateOf(5) }
    
    // Auto-decrement countdown with audio cues
    LaunchedEffect(prepCountdown) {
        if (prepCountdown > 0) {
            if (prepCountdown == 5) {
                onSpeakRequested("Get ready")
            } else {
                onSpeakRequested("$prepCountdown")
            }
            kotlinx.coroutines.delay(1000)
            prepCountdown--
            if (prepCountdown == 0) {
                onSpeakRequested("Go! Work!")
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!cameraPermissionState.status.isGranted) {
            cameraPermissionState.launchPermissionRequest()
        }
    }

    if (!cameraPermissionState.status.isGranted) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Camera Permission Required",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Camera capability is used for detecting motion and automatically counting repetitions.",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { cameraPermissionState.launchPermissionRequest() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316))
                ) {
                    Text("Grant Permission", color = Color.White)
                }
            }
        }
    } else {
        Box(modifier = Modifier.fillMaxSize()) {
            val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
            val executorService = remember { Executors.newSingleThreadExecutor() }

            val previewView = remember { PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }

            LaunchedEffect(cameraLensFacing, lifecycleOwner) {
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(cameraLensFacing)
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                imageAnalysis.setAnalyzer(executorService, PoseAnalyzer(
                    onPoseDetected = { pose, w, h ->
                        detectedPose = pose
                        imageWidth = w
                        imageHeight = h
                    },
                    onMotion = { motion ->
                        isMotionDetected = motion
                    },
                    onRep = {
                        if (prepCountdown == 0) {
                            motionPulseCount++
                            if (motionPulseCount >= 2) {
                                motionPulseCount = 0
                                detectedReps++
                                onRepCounted()
                                if (detectedReps >= targetReps) {
                                    onSetCompleted()
                                }
                            }
                        }
                    }
                ))

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageAnalysis
                    )
                    isCameraReady = true
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            // Camera preview container
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize()
            )

            // Pose Overlay Canvas for stickman
            if (detectedPose != null) {
                androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                    val pose = detectedPose!!
                    val landmarks = pose.allPoseLandmarks
                    if (landmarks.isNotEmpty()) {
                        val imgW = if (imageWidth > imageHeight) imageHeight else imageWidth
                        val imgH = if (imageWidth > imageHeight) imageWidth else imageHeight
                        
                        val sX = size.width / imgW
                        val sY = size.height / imgH
                        val s = Math.max(sX, sY)

                        val offsetX = (size.width - imgW * s) / 2f
                        val offsetY = (size.height - imgH * s) / 2f

                        fun mapToView(landmark: com.google.mlkit.vision.pose.PoseLandmark?): androidx.compose.ui.geometry.Offset? {
                            if (landmark == null) return null
                            val cx = if (cameraLensFacing == CameraSelector.LENS_FACING_FRONT) {
                                size.width - (landmark.position.x * s + offsetX)
                            } else {
                                landmark.position.x * s + offsetX
                            }
                            val cy = landmark.position.y * s + offsetY
                            return androidx.compose.ui.geometry.Offset(cx, cy)
                        }

                        fun drawConnection(p1: com.google.mlkit.vision.pose.PoseLandmark?, p2: com.google.mlkit.vision.pose.PoseLandmark?) {
                            if (p1 != null && p2 != null) {
                                val o1 = mapToView(p1)
                                val o2 = mapToView(p2)
                                if (o1 != null && o2 != null) {
                                    drawLine(
                                        color = Color(0xFF00E5FF),
                                        start = o1,
                                        end = o2,
                                        strokeWidth = 6.dp.toPx(),
                                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                                    )
                                }
                            }
                        }
                        
                        fun drawLandmark(p: com.google.mlkit.vision.pose.PoseLandmark?) {
                            if (p != null) {
                                val o = mapToView(p)
                                if (o != null) {
                                    drawCircle(color = Color.White, radius = 4.dp.toPx(), center = o)
                                }
                            }
                        }

                        val leftShoulder = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_SHOULDER)
                        val rightShoulder = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_SHOULDER)
                        val leftElbow = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_ELBOW)
                        val rightElbow = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_ELBOW)
                        val leftWrist = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_WRIST)
                        val rightWrist = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_WRIST)
                        val leftHip = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_HIP)
                        val rightHip = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_HIP)
                        val leftKnee = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_KNEE)
                        val rightKnee = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_KNEE)
                        val leftAnkle = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.LEFT_ANKLE)
                        val rightAnkle = pose.getPoseLandmark(com.google.mlkit.vision.pose.PoseLandmark.RIGHT_ANKLE)

                        drawConnection(leftShoulder, rightShoulder)
                        drawConnection(leftShoulder, leftElbow)
                        drawConnection(leftElbow, leftWrist)
                        drawConnection(rightShoulder, rightElbow)
                        drawConnection(rightElbow, rightWrist)
                        drawConnection(leftShoulder, leftHip)
                        drawConnection(rightShoulder, rightHip)
                        drawConnection(leftHip, rightHip)
                        drawConnection(leftHip, leftKnee)
                        drawConnection(leftKnee, leftAnkle)
                        drawConnection(rightHip, rightKnee)
                        drawConnection(rightKnee, rightAnkle)

                        listOf(leftShoulder, rightShoulder, leftElbow, rightElbow, leftWrist, rightWrist,
                            leftHip, rightHip, leftKnee, rightKnee, leftAnkle, rightAnkle).forEach { drawLandmark(it) }
                    }
                }
            }

            // Centered Target ROI Bounding Box
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.Center)
                    .border(
                        width = 4.dp,
                        color = if (isMotionDetected && prepCountdown == 0) Color(0xFF22C55E) else Color(0x80F97316),
                        shape = RoundedCornerShape(24.dp)
                    )
            )

            // Bottom camera controls
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xE0000000))
                    .padding(horizontal = 24.dp, vertical = 24.dp)
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = exerciseName,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFF97316), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("SET $currentSetNum/$totalSets", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Box(
                                modifier = Modifier
                                    .background(Color.White, shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("GOAL: $targetReps REPS", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Large glowing rep counter with 2-step motion phase feedback
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF0F0F0F), shape = RoundedCornerShape(16.dp))
                            .border(1.dp, Color(0xFF262626), shape = RoundedCornerShape(16.dp))
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$detectedReps",
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 36.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (motionPulseCount == 1) "PHASE: 1/2 (DOWN)" else "PHASE: READY",
                                color = if (motionPulseCount == 1) Color.Cyan else Color.White.copy(alpha = 0.6f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isMotionDetected && prepCountdown == 0) "MOTION" else "STABLE",
                                color = if (isMotionDetected && prepCountdown == 0) Color(0xFF22C55E) else Color(0xFFF97316),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Flip lens
                        IconButton(
                            onClick = {
                                cameraLensFacing = if (cameraLensFacing == CameraSelector.LENS_FACING_FRONT) {
                                    CameraSelector.LENS_FACING_BACK
                                } else {
                                    CameraSelector.LENS_FACING_FRONT
                                }
                            },
                            modifier = Modifier.background(Color(0xFF262626), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Switch Camera", tint = Color.White)
                        }

                        // Complete early
                        IconButton(
                            onClick = { onSetCompleted() },
                            modifier = Modifier.background(Color(0xFF22C55E), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.Done, contentDescription = "Done", tint = Color.White)
                        }
                    }
                }
            }

            // Top exit panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0xA0000000))
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .statusBarsPadding(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MOTION TRACKER ACTIVE",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                IconButton(
                    onClick = onExit,
                    modifier = Modifier.size(32.dp).background(Color(0x80000000), RoundedCornerShape(50))
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Camera", tint = Color.White)
                }
            }

            // High priority prep countdown overlay
            if (prepCountdown > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xE6000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$prepCountdown",
                            color = Color(0xFFF97316),
                            fontSize = 120.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 120.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "GET IN THE RED FRAME BOX!",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }
    }
}

// Low resource gray-scale Y-channel frame analyzer
private class MotionAnalyzer(
    private val onMotion: (Boolean) -> Unit,
    private val onRep: () -> Unit
) : ImageAnalysis.Analyzer {
    private var lastLuminance: Double? = null
    private var lastTriggerTime = 0L
    private var state = "stable" // "stable" or "active"
    private val threshold = 3.2

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val planeY = imageProxy.planes[0]
        val buffer = planeY.buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)

        val width = imageProxy.width
        val height = imageProxy.height

        // Define a central sub-sampled window coordinates of 100x100
        val boxWidth = 100
        val boxHeight = 100
        val startX = (width - boxWidth) / 2
        val startY = (height - boxHeight) / 2

        var sum = 0.0
        var pixelCount = 0

        val rowStride = planeY.rowStride
        val pixelStride = planeY.pixelStride

        for (y in startY until (startY + boxHeight) step 2) {
            for (x in startX until (startX + boxWidth) step 2) {
                val index = y * rowStride + x * pixelStride
                if (index < data.size) {
                    sum += data[index].toInt() and 0xFF
                    pixelCount++
                }
            }
        }

        val currentLuminance = if (pixelCount > 0) sum / pixelCount else 0.0
        val now = System.currentTimeMillis()

        if (lastLuminance != null) {
            val diff = Math.abs(currentLuminance - lastLuminance!!)
            val isMotion = diff > threshold

            onMotion(isMotion)

            if (isMotion) {
                // If it goes from fully stable to active and stays separated by at least 1000ms, it is 1 full motion rep!
                if (state == "stable" && (now - lastTriggerTime > 1000)) {
                    state = "active"
                    lastTriggerTime = now
                    onRep()
                }
            } else {
                if (state == "active" && (now - lastTriggerTime > 400)) {
                    state = "stable"
                }
            }
        }

        lastLuminance = currentLuminance
        imageProxy.close()
    }
}

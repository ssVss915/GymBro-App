package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale
import com.example.ui.components.CameraMotionTracker
import com.example.ui.components.ExerciseVideoPlayer
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GymBroViewModel
import com.example.ui.viewmodel.GymBroViewModelFactory
import com.example.ui.viewmodel.WorkoutState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                GymBroAppContainer()
            }
        }
    }
}

@Composable
fun GymBroAppContainer() {
    val context = LocalContext.current
    val application = context.applicationContext as android.app.Application
    val viewModel: GymBroViewModel = viewModel(factory = GymBroViewModelFactory(application))

    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val todayDate by viewModel.todayDate.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val selectedDayOfWeek by viewModel.selectedDayOfWeek.collectAsStateWithLifecycle()

    // Reactive progress streams
    val selectedProgress by viewModel.selectedDayProgress.collectAsStateWithLifecycle()
    val allProgressList by viewModel.allProgressList.collectAsStateWithLifecycle()

    // Active Workout properties
    val workoutState by viewModel.activeWorkoutState.collectAsStateWithLifecycle()
    val activeExIndex by viewModel.activeExIndex.collectAsStateWithLifecycle()
    val activeSetNum by viewModel.activeSetNum.collectAsStateWithLifecycle()
    val restTimeRemaining by viewModel.restTimeRemaining.collectAsStateWithLifecycle()
    val activeExTimeRemaining by viewModel.activeExTimeRemaining.collectAsStateWithLifecycle()
    val isTimeExRunning by viewModel.isTimeExerciseRunning.collectAsStateWithLifecycle()
    val cameraReps by viewModel.cameraReps.collectAsStateWithLifecycle()
    val isMotionActive by viewModel.isMotionActive.collectAsStateWithLifecycle()
    val prepTimeRemaining by viewModel.prepTimeRemaining.collectAsStateWithLifecycle()

    // Music Player properties
    val isPlayingSong by viewModel.isPlayingSong.collectAsStateWithLifecycle()
    val currentSongIdx by viewModel.currentSongIdx.collectAsStateWithLifecycle()

    var cameraStateActive by remember { mutableStateOf(false) }
    var viewTutorialActive by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0A0F)),
        bottomBar = {
            if (workoutState == WorkoutState.Idle && !cameraStateActive) {
                NavigationBar(
                    containerColor = Color(0xFF141218),
                    modifier = Modifier
                        .border(1.dp, Color(0xFF49454F).copy(alpha = 0.4f), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("app_bottom_nav_bar")
                ) {
                    val tabs = listOf(
                        Triple("home", "Home", Icons.Default.Home),
                        Triple("workout", "Workout", Icons.Default.FitnessCenter),
                        Triple("water", "Water", Icons.Default.WaterDrop),
                        Triple("music", "Music", Icons.Default.MusicNote),
                        Triple("calendar", "Calendar", Icons.Default.DateRange)
                    )

                    tabs.forEach { (tabId, label, icon) ->
                        val selected = currentTab == tabId
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.setCurrentTab(tabId) },
                            icon = {
                                Icon(
                                    icon,
                                    contentDescription = label,
                                    tint = if (selected) MaterialTheme.colorScheme.primary else Color(0xFFC4C6CF),
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else Modifier.let { FontWeight.Medium },
                                    color = if (selected) Color(0xFFE2E2E6) else Color(0xFFC4C6CF)
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("navigation_tab_$tabId")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF0C0A0F))
        ) {
            when (workoutState) {
                is WorkoutState.Idle -> {
                    when (currentTab) {
                        "home" -> {
                            val todayDayOfWeek = remember(todayDate) {
                                try {
                                    val dfFormat = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                                    val parseDate = dfFormat.parse(todayDate)
                                    if (parseDate != null) {
                                        java.text.SimpleDateFormat("EEEE", java.util.Locale.US).format(parseDate)
                                    } else {
                                        "Monday"
                                    }
                                } catch(e: Exception) {
                                    "Monday"
                                }
                            }
                            val todayRoutine = viewModel.workoutSchedules[todayDayOfWeek]
                            val todayLogs by viewModel.selectedDayExerciseLogs.collectAsStateWithLifecycle()

                            HomeScreen(
                                routine = todayRoutine,
                                todayLogs = todayLogs,
                                onStartWorkoutResume = { exIdx ->
                                    viewModel.startExerciseWithResume(exIdx)
                                    viewTutorialActive = false
                                    cameraStateActive = false
                                }
                            )
                        }

                        "workout" -> {
                            val routineWeekDay = viewModel.workoutSchedules[selectedDayOfWeek]
                            WorkoutScreen(
                                selectedDay = selectedDayOfWeek,
                                routine = routineWeekDay,
                                onSelectDay = { viewModel.selectDayOfWeek(it) },
                                onStartExercise = { exIdx ->
                                    viewModel.startExerciseWithResume(exIdx)
                                    viewTutorialActive = false
                                    cameraStateActive = false
                                }
                            )
                        }

                        "water" -> {
                            val checkedSlots by viewModel.checkedWaterSlots.collectAsStateWithLifecycle()
                            val currentProgress by viewModel.selectedDayProgress.collectAsStateWithLifecycle()
                            val currentWaterMl = currentProgress?.waterMl ?: 0

                            WaterScreen(
                                currentWaterMl = currentWaterMl,
                                checkedSlots = checkedSlots,
                                onToggleSlot = { slot, checked ->
                                    viewModel.toggleWaterSlot(slot.id, checked)
                                }
                            )
                        }

                        "music" -> {
                            val songsList by viewModel.songsList.collectAsStateWithLifecycle()
                            MusicScreen(
                                songs = songsList,
                                activeSongIdx = currentSongIdx,
                                isPlaying = isPlayingSong,
                                onTogglePlay = { viewModel.toggleSongPlay() },
                                onNext = { viewModel.playNextSong() },
                                onPrev = { viewModel.playPrevSong() },
                                onSelectSong = { viewModel.selectSong(it) },
                                onAddCustomSong = { title, genre -> viewModel.uploadCustomSong(title, genre) },
                                onDeleteSong = { idx -> viewModel.deleteCustomSong(idx) }
                            )
                        }

                        "calendar" -> {
                            CalendarScreen(
                                allProgress = allProgressList
                            )
                        }
                    }
                }

                is WorkoutState.Exercising -> {
                    // Active Workout Screen
                    val activeRoutine = viewModel.workoutSchedules[selectedDayOfWeek] ?: viewModel.workoutSchedules["Monday"]!!
                    val activeEx = activeRoutine.exercises[activeExIndex]

                    if (cameraStateActive) {
                        // Open CameraX interactive analyzer
                        CameraMotionTracker(
                            exerciseName = activeEx.name,
                            targetReps = activeEx.reps.toIntOrNull() ?: 12,
                            currentSetNum = activeSetNum,
                            totalSets = activeEx.sets,
                            onRepCounted = {
                                viewModel.incrementCameraReps()
                            },
                            onSetCompleted = {
                                viewModel.completeSet()
                                cameraStateActive = false
                            },
                            onExit = {
                                cameraStateActive = false
                            }
                        )
                    } else {
                        // Overview walkthrough showing custom 5-second Vector Animator first
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top close
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { viewModel.exitWorkout() }) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Exit", tint = Color.White)
                                }
                                Text(
                                    text = "ACTIVE WORKOUT SESSION",
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                )
                                Text(
                                    text = "${activeExIndex + 1}/${activeRoutine.exercises.size}",
                                    color = Color.LightGray,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = activeEx.name,
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFF97316), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("SET $activeSetNum/${activeEx.sets}", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .border(1.dp, Color(0xFF1F1F26), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("REPS: ${activeEx.reps}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Dynamic tutorial vector animator
                            if (viewTutorialActive) {
                                ExerciseVideoPlayer(
                                    exerciseName = activeEx.name,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                Button(
                                    onClick = { viewTutorialActive = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F0F12)),
                                    modifier = Modifier.border(1.dp, Color(0xFF1E1E24), RoundedCornerShape(12.dp))
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFF97316))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("View 5s Setup Video Setup", color = Color.White)
                                    }
                                }
                            }

                            // Live Timer if time-bound exercise
                            if (activeEx.type == "time") {
                                val remaining = activeExTimeRemaining ?: 60
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = String.format(Locale.US, "%02d:%02d", remaining / 60, remaining % 60),
                                        color = if (remaining == 0) Color.Red else Color.White,
                                        fontSize = 54.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = { viewModel.toggleTimeExerciseTimer() },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isTimeExRunning) Color(0x33F97316) else Color(0xFFF97316)
                                        )
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isTimeExRunning) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                                contentDescription = null,
                                                tint = if (isTimeExRunning) Color(0xFFF97316) else Color.Black
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (isTimeExRunning) "PAUSE TIMER" else "START TIMER",
                                                color = if (isTimeExRunning) Color(0xFFF97316) else Color.Black,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }

                            Column(modifier = Modifier.fillMaxWidth()) {
                                // Launch Camera action button
                                Button(
                                    onClick = { cameraStateActive = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316)),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(56.dp)
                                        .testTag("launch_camera_button")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.Black)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Start Smart Camera Tracker", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))

                                // Complete manually row bypass key
                                TextButton(
                                    onClick = { viewModel.completeSet() },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Done, contentDescription = null, tint = Color(0xFF22C55E))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Complete Set Manually", color = Color(0xFF22C55E), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                is WorkoutState.Resting -> {
                    // Rest overlay counting down
                    val activeRoutine = viewModel.workoutSchedules[selectedDayOfWeek] ?: viewModel.workoutSchedules["Monday"]!!
                    val nextEx = activeRoutine.exercises.getOrNull(activeExIndex)

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.Timer,
                            contentDescription = "Timer",
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Catch Your Breath!",
                            color = Color.LightGray,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${restTimeRemaining}s",
                            color = Color.White,
                            fontSize = 80.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        if (nextEx != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0F0F12), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFF1E1E24), RoundedCornerShape(16.dp))
                                    .padding(16.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "UP NEXT:",
                                        color = Color(0xFFF97316),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = nextEx.name,
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${nextEx.sets} Sets @ ${nextEx.reps}",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(32.dp))

                        Button(
                            onClick = { viewModel.skipRest() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FastForward, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SKip Rest", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                is WorkoutState.Completed -> {
                    // Big premium congratulations screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🏆",
                            fontSize = 90.sp
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Congratulations! 🔥",
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Workout completed successfully. Keep up the high discipline and stay hydrated!",
                            color = Color.LightGray,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(44.dp))
                        Button(
                            onClick = { viewModel.exitWorkout() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Text("Back to Home", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                    }
                }

                is WorkoutState.CorePrep -> {
                    // Readying camera or assets state
                }
            }
        }
    }
}

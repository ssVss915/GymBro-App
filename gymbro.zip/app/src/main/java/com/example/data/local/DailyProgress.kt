package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_progress")
data class DailyProgress(
    @PrimaryKey val date: String, // format "yyyy-MM-dd"
    val workoutCompleted: Boolean = false,
    val dietCompleted: Boolean = false,
    val waterMl: Int = 0,
    val customDietPlan: String? = null // Customized diet text/JSON
)

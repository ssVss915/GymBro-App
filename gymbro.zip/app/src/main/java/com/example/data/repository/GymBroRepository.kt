package com.example.data.repository

import com.example.data.local.DailyProgress
import com.example.data.local.DailyProgressDao
import com.example.data.local.ExerciseLog
import com.example.data.local.ExerciseLogDao
import kotlinx.coroutines.flow.Flow

class GymBroRepository(
    private val dailyProgressDao: DailyProgressDao,
    private val exerciseLogDao: ExerciseLogDao
) {
    fun getProgressByDate(date: String): Flow<DailyProgress?> = dailyProgressDao.getProgressByDate(date)

    suspend fun getProgressByDateSync(date: String): DailyProgress? = dailyProgressDao.getProgressByDateSync(date)

    val allDailyProgress: Flow<List<DailyProgress>> = dailyProgressDao.getAllProgress()

    suspend fun insertOrUpdateProgress(progress: DailyProgress) {
        dailyProgressDao.insertOrUpdateProgress(progress)
    }

    suspend fun updateWaterIntake(date: String, waterMl: Int) {
        val existing = getProgressByDateSync(date)
        if (existing == null) {
            insertOrUpdateProgress(DailyProgress(date = date, waterMl = waterMl))
        } else {
            dailyProgressDao.updateWaterIntake(date, waterMl)
        }
    }

    suspend fun updateWorkoutCompletion(date: String, completed: Boolean) {
        val existing = getProgressByDateSync(date)
        if (existing == null) {
            insertOrUpdateProgress(DailyProgress(date = date, workoutCompleted = completed))
        } else {
            dailyProgressDao.updateWorkoutCompletion(date, completed)
        }
    }

    suspend fun updateDietCompletion(date: String, completed: Boolean) {
        val existing = getProgressByDateSync(date)
        if (existing == null) {
            insertOrUpdateProgress(DailyProgress(date = date, dietCompleted = completed))
        } else {
            dailyProgressDao.updateDietCompletion(date, completed)
        }
    }

    suspend fun saveCustomDietPlan(date: String, planJson: String) {
        val existing = getProgressByDateSync(date) ?: DailyProgress(date = date)
        insertOrUpdateProgress(existing.copy(customDietPlan = planJson))
    }

    // Exercise logs
    fun getExerciseLogsByDate(date: String): Flow<List<ExerciseLog>> = exerciseLogDao.getLogsByDate(date)

    suspend fun insertExerciseLog(log: ExerciseLog) = exerciseLogDao.insertLog(log)

    suspend fun deleteExerciseLogById(id: Int) = exerciseLogDao.deleteLogById(id)
}

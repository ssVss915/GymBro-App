package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseLogDao {
    @Query("SELECT * FROM exercise_logs WHERE date = :date ORDER BY timestamp DESC")
    fun getLogsByDate(date: String): Flow<List<ExerciseLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ExerciseLog)

    @Query("DELETE FROM exercise_logs WHERE id = :id")
    suspend fun deleteLogById(id: Int)

    @Query("DELETE FROM exercise_logs")
    suspend fun clearAllLogs()
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercise_logs")
data class ExerciseLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // format "yyyy-MM-dd"
    val exerciseName: String,
    val repsCompleted: Int,
    val setsCompleted: Int,
    val timestamp: Long = System.currentTimeMillis()
)

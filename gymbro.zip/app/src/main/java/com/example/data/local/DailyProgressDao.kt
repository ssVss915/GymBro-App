package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyProgressDao {
    @Query("SELECT * FROM daily_progress WHERE date = :date LIMIT 1")
    fun getProgressByDate(date: String): Flow<DailyProgress?>

    @Query("SELECT * FROM daily_progress WHERE date = :date LIMIT 1")
    suspend fun getProgressByDateSync(date: String): DailyProgress?

    @Query("SELECT * FROM daily_progress ORDER BY date ASC")
    fun getAllProgress(): Flow<List<DailyProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProgress(progress: DailyProgress)

    @Query("UPDATE daily_progress SET waterMl = :waterMl WHERE date = :date")
    suspend fun updateWaterIntake(date: String, waterMl: Int)

    @Query("UPDATE daily_progress SET workoutCompleted = :completed WHERE date = :date")
    suspend fun updateWorkoutCompletion(date: String, completed: Boolean)

    @Query("UPDATE daily_progress SET dietCompleted = :completed WHERE date = :date")
    suspend fun updateDietCompletion(date: String, completed: Boolean)
}
